
local numBorder=24
local numTile=0
local BorderTypes = { [1] = "PavingStone", [2] = "ConcreteTiles", [3] = "Stone", [4] = "WoodenFloor", [5] = "MosaicFloor", [6] = "MetalFloor", [7] = "Dirt", [8] = "Grass", [9] = "LongGrass", [10] = "Mud", [11] = "CeramicFloor", [12] = "Sand", [13] = "MarbleTiles", [14] = "WhiteTiles", [15] = "FancyTiles", [16] = "Gravel", [17] = "BorderWater", [18] = "Cobblestone",  [19] = "Road", [20] = "RoadMarkingsLeft", [21] = "RoadMarkingsRight", [22] = "RoadCrossingLeft", [23] = "RoadCrossingRight", [24] = "WaterStable" }
local FloorDescription = { [0] = "tooltip_CurrentTile", [1] = "tooltip_PavingStone", [2] = "tooltip_ConcreteTiles", [3] = "tooltip_Stone", [4] = "tooltip_WoodenFloor", [5] = "tooltip_MosaicFloor", [6] = "tooltip_MetalFloor", [7] = "tooltip_Dirt", [8] = "tooltip_Grass", [9] = "tooltip_LongGrass", [10] = "tooltip_Mud", [11] = "tooltip_CeramicFloor", [12] = "tooltip_Sand", [13] = "tooltip_MarbleTiles", [14] = "tooltip_WhiteTiles", [15] = "tooltip_FancyTiles", [16] = "tooltip_Gravel", [17] = "tooltip_BorderWater", [18] = "tooltip_Cobblestone", [19] = "tooltip_Road", [20] = "tooltip_RoadMarkingsLeft", [21] = "tooltip_RoadMarkingsRight", [22] = "tooltip_RoadCrossingLeft", [23] = "tooltip_RoadCrossingRight", [24] = "tooltip_WaterStable", [25] = "tooltip_ChangeBorder" }

function Create()
	Interface.AddComponent(this,"0bc", "Caption", "tooltip_divider")
	Interface.AddComponent(this,"1bc", "Caption", "tooltip_borderoptions")
	mynumBorder=numBorder
	Object.SetProperty(this,"mynumBorder",mynumBorder)
	Interface.AddComponent(this,"toggleBorderType", "Button", "tooltip_button_border",FloorDescription[this.mynumBorder],"X")
	
	Interface.AddComponent(this,"2bc", "Caption", "tooltip_divider")
	Interface.AddComponent(this,"3bc", "Caption", "tooltip_tileoptions")
	mynumTile=numTile
	Object.SetProperty(this,"mynumTile",mynumTile)
	Interface.AddComponent(this,"toggleTileTypePlus", "Button", "tooltip_button_tileplus")
	Interface.AddComponent(this,"4bc", "Caption", "tooltip_tile",FloorDescription[this.mynumTile],"X")
	Interface.AddComponent(this,"toggleTileTypeMinus", "Button", "tooltip_button_tileminus")

	Interface.AddComponent(this,"5bc", "Caption", "tooltip_divider")
	Interface.AddComponent(this,"copyUp", "Button", "tooltip_up")
	Interface.AddComponent(this,"copyDown", "Button", "tooltip_down")
	Interface.AddComponent(this,"copyLeft", "Button", "tooltip_left")
	Interface.AddComponent(this,"copyRight", "Button", "tooltip_right")
	this.Or.x = 0
	this.Or.y = 1
end

function toggleBorderTypeClicked()
	numBorder=numBorder+1
	if numBorder>19 then numBorder=1 end
	Object.SetProperty(this,"mynumBorder",numBorder)
	this.SetInterfaceCaption("toggleBorderType", "tooltip_button_border",FloorDescription[this.mynumBorder],"X")
	MakeBorder(BorderTypes[numBorder])
end

function toggleTileTypePlusClicked()
	numTile=numTile+1
	if numTile>24 then numTile=1 end
	Object.SetProperty(this,"mynumTile",numTile)
	this.SetInterfaceCaption("4bc", "tooltip_tile",FloorDescription[this.mynumTile],"X")
	SetTile(BorderTypes[numTile])
end

function toggleTileTypeMinusClicked()
	numTile=numTile-1
	if numTile<1 then numTile=24 end
	Object.SetProperty(this,"mynumTile",numTile)
	this.SetInterfaceCaption("4bc", "tooltip_tile",FloorDescription[this.mynumTile],"X")
	SetTile(BorderTypes[numTile])
end

function SetTile(TileType)
	local x = math.floor(this.Pos.x)
	local y = math.floor(this.Pos.y)
	local cell = World.GetCell(x,y)
	cell.Mat = TileType
end

function MakeBorder(BorderType)
	local endX=-1
	local endY=-1
	local foundEndX=false
	local foundEndY=false

	while foundEndX==false do
		endX=endX+1
		local cell = World.GetCell(0,endX)
		if cell.Mat~=nil then
			cell.Mat=BorderType
		else
			endX=endX-1
			foundEndX=true
		end
	end

	while foundEndY==false do
		endY=endY+1
		local TopRowCell = World.GetCell(endY,0)
		local BottomRowCell = World.GetCell(endY,endX)
		if TopRowCell.Mat~=nil then
			if TopRowCell.Mat=="RoadMarkingsLeft" then
				local prevTopRowCell = World.GetCell(endY-1,0)
				local prevBottomRowCell = World.GetCell(endY-1,endX)
				prevTopRowCell.Mat="ConcreteTiles"
				prevBottomRowCell.Mat="ConcreteTiles"
				local SingleLaneRoadCheck = World.GetCell(endY+1,0)
				if SingleLaneRoadCheck.Mat == "RoadMarkingsRight" then
					endY = endY+2
				else
					endY = endY+5
				end
			else
				TopRowCell.Mat=BorderType
				BottomRowCell.Mat=BorderType
			end
		else
			endY=endY-1
			foundEndY=true
		end
		
	end
	
	for i=0,endX do
		local cell = World.GetCell(endY,i)
		cell.Mat=BorderType
 	end
	
end

function copyUpClicked()
	local x = math.floor(this.Pos.x)
	local y = math.floor(this.Pos.y)
	local cell = World.GetCell(x,y-1)
	cell.Mat = Object.GetMaterial(x,y)
	this.Pos.y = this.Pos.y-1
end

function copyDownClicked()
	local x = math.floor(this.Pos.x)
	local y = math.floor(this.Pos.y)
	local cell = World.GetCell(x,y+1)
	cell.Mat = Object.GetMaterial(x,y)
	this.Pos.y = this.Pos.y+1
end

function copyRightClicked()
	local x = math.floor(this.Pos.x)
	local y = math.floor(this.Pos.y)
	local cell = World.GetCell(x+1,y)
	cell.Mat = Object.GetMaterial(x,y)
	this.Pos.x = this.Pos.x+1
end

function copyLeftClicked()
	local x = math.floor(this.Pos.x)
	local y = math.floor(this.Pos.y)
	local cell = World.GetCell(x-1,y)
	cell.Mat = Object.GetMaterial(x,y)
	this.Pos.x = this.Pos.x-1
end
