
function Create()
	Object.SetProperty("IsEmpty", true);
	
	Object.SetProperty("TimerFerti", 0.0);
	
	Object.SetProperty("NeedWater", true);
	Object.SetProperty("TimerWater", 0.0);
	Object.CreateJob("WaterGardenPlant");
	
	Object.CreateJob("PlantGardenSeed");
	Object.SetProperty("Tooltip", "tooltip_pot_empty");
end


function Update( timePassed )
	-- if pot is empty, plant seeds
    if Object.GetProperty("IsEmpty") then		
		return;
	end
	
	-- Check fertilizer level
	if Object.GetProperty("NeedFerti") ~= true then
		local timer = tonumber(Object.GetProperty("TimerFerti")) + timePassed;
		Object.SetProperty("TimerFerti", timer);
		
		-- need to fertilize every 2 days
		if timer > 2880 then
			Object.SetProperty("NeedFerti", true);
			Object.CreateJob("FertilizeGardenPlant");
			Object.SetProperty("Tooltip", "tooltip_pot_need_fertilizer");
		end
	end
	
	-- Check water level
	if Object.GetProperty("NeedWater") ~= true then
		local timer = tonumber(Object.GetProperty("TimerWater")) + timePassed;
		Object.SetProperty("TimerWater", timer);
		
		-- need to water every day
		if timer > 1440 then
			Object.SetProperty("NeedWater", true);
			Object.CreateJob("WaterGardenPlant");
			Object.SetProperty("Tooltip", "tooltip_pot_need_water");
		end
	end
	
	-- Calculate age
	if Object.GetProperty("IsRipe") ~= true then
		local age = timePassed;
		
		-- if plant needs water or fertilizer, grows at half rate
		if Object.GetProperty("NeedFerti") or Object.GetProperty("NeedWater") then
			age = age * 0.5;
		end
		age = Object.GetProperty("Age") + age;		
		Object.SetProperty("Age", age);
		
		local subType = 1;
		if age > tonumber(Object.GetProperty("MaxAge")) then
			local subToPlantType = {
				GardenTomato = 3,
				GardenCucumber = 4,
				GardenRose = 5,
				GardenLily = 6
			};
			subType = subToPlantType[Object.GetProperty("PlantType")];
			Object.SetProperty("IsRipe", true);
			Object.CreateJob("HarvestGardenPlant");
			Object.SetProperty("Tooltip", "tooltip_pot_ready_for_harvest");
		elseif age > Object.GetProperty("MaxAge") * 0.5 then
			subType = 2;
		end

		if Object.GetProperty("SubType") ~= subType then
			Object.SetProperty("SubType", subType);
		end
	end
end

function JobComplete_PlantGardenSeed()
    Object.SetProperty("IsEmpty", false);
	Object.SetProperty("Tooltip", "");
	Object.SetProperty("Age", 0.0);
	Object.SetProperty("SubType", 1);
	
    -- Growing time 3~5 days
	Object.SetProperty("MaxAge", 1440 * (3 + math.random(2)));
	--Object.SetProperty("MaxAge", 600);
	
	-- Can be harvested 1~3 times
	Object.SetProperty("RemainHarvest", math.random(3));
	
	-- plant type
	local rand = math.random();
	if rand < 0.25 then
		Object.SetProperty("PlantType", "GardenTomato");
	elseif rand < 0.5 then
		Object.SetProperty("PlantType", "GardenCucumber");
	elseif rand < 0.75 then 
		Object.SetProperty("PlantType", "GardenRose");
	else
		Object.SetProperty("PlantType", "GardenLily");
	end
end

function JobComplete_FertilizeGardenPlant()
	Object.SetProperty("TimerFerti", 0.0);
	Object.SetProperty("NeedFerti", false);
	Object.SetProperty("Tooltip", "");
end

function JobComplete_WaterGardenPlant()
	Object.SetProperty("TimerWater", 0.0);
	Object.SetProperty("NeedWater", false);
	Object.SetProperty("Tooltip", "");
end

function JobComplete_HarvestGardenPlant()	
	Object.SetProperty("IsRipe", false);
	Object.SetProperty("Tooltip", "");	
	
	local ourX = Object.GetProperty("Pos.x");
    local ourY = Object.GetProperty("Pos.y");
	-- each harvest produces 1 - 3 results
	local outNum = math.random(3); 
	local outType = Object.GetProperty("PlantType");
	
	for i = 1, outNum do
		local name = Object.Spawn( outType, ourX, ourY );
		local velX = -1.0 + math.random() + math.random();
        local velY = -1.0 + math.random() + math.random();
		Object.ApplyVelocity(name, velX, velY);
	end
	
	local remainTime = tonumber(Object.GetProperty("RemainHarvest"));
	if remainTime == 0 then
		Object.SetProperty("SubType", 7);
		Object.CreateJob("RemoveDeadGardenPlant");
		Object.SetProperty("Tooltip", "tooltip_pot_dead");	
	else
		local maxAge = tonumber(Object.GetProperty("MaxAge"));
		Object.SetProperty("SubType", 2);
		Object.SetProperty("RemainHarvest", remainTime-1);
		Object.SetProperty("Age", maxAge - 1440);
	end
end

function JobComplete_RemoveDeadGardenPlant()
	Object.SetProperty("IsEmpty", true);
	Object.SetProperty("SubType", 0);
	Object.CreateJob("PlantGardenSeed");
	Object.SetProperty("Tooltip", "tooltip_pot_empty");
	
	local ourX = Object.GetProperty("Pos.x");
    local ourY = Object.GetProperty("Pos.y");
	local name = Object.Spawn( "GardenDeadPlant", ourX, ourY );
	local velX = -1.0 + math.random() + math.random();
	local velY = -1.0 + math.random() + math.random();
	Object.ApplyVelocity(name, velX, velY);
end

