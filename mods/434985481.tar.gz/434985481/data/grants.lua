function CreateGrants()
	CreateSimpleGardenGrants();
end


function CreateSimpleGardenGrants()
	Objective.CreateGrant			( "Grant_Simple_Garden", 5000, 20000 )
	Objective.SetPreRequisite		( "Unlocked", "Gardening", 0 )
	Objective.HiddenWhileLocked 	()
	
	Objective.CreateGrant			( "Grant_Simple_Garden_GardenRoom", 0, 0 )
	Objective.SetParent				( "Grant_Simple_Garden" )
	Objective.RequireRoom			( "Garden", true )
	
	Objective.CreateGrant			( "Grant_Simple_Garden_GardenPotNumber", 0, 0 )
	Objective.SetParent				( "Grant_Simple_Garden" )
	Objective.RequireObjects		( "GardenPlantPot", 10 )
	
	Objective.CreateGrant			( "Grant_Simple_Garden_GardenerNumber", 0, 0 )
	Objective.SetParent				( "Grant_Simple_Garden" )
	Objective.RequireObjects		( "Gardener", 1 )
	
	Objective.CreateGrant			( "Grant_Simple_Garden_ProgramPassed", 0, 0 )
	Objective.SetParent				( "Grant_Simple_Garden" )
	Objective.Requires				( "ReformPassed", "PlantCultivation", 20 )
	
	Objective.CreateGrant			( "Grant_Simple_Garden_GardenHarvest", 0, 0)
	Objective.SetParent				( "Grant_Simple_Garden" )
	Objective.Requires				( "PrisonerJobs", "Garden", 5 )
end