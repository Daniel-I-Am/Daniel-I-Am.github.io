-- vehicle types; add more if desired (remember to define tooltips in base-language.txt)
local Traffic = { -- vehicle name = approx length (most common vehicles first, least common last)
	SupplyTruck = 5,
	PrisonerBus = 5,
	Hearse      = 4,
	Ambulance   = 4,
	RiotVan     = 4,
	FireEngine  = 5,
	TroopTruck  = 4,
	Limo        = 4
}

-- connected wire output (0 = false, 2 = true)
local Output   = 0;

-- despam Update():
local Now       = Game.Time;
local Delay     = 1; -- game seconds
local Ready     = Now();

-- finding nearby stuff
local Find       = next;
local First      = this.GetNearbyObjects;
local Proximity  = 2; -- tiles

-- object properties
local Get        = Object.GetProperty;
local OurY       = this.Pos.y;
local OurX 	 = this.Pos.x;


function Create()

	this.Tooltip   = "tooltip_initialising_sensors";
	this.Triggered = Output;

end


function Update()

    if Now() > Ready then

    	Output = CheckSensors();

        -- Ready = Ready + Delay;
        Ready  = Now() + Delay;  -- Bug #6178: PA does not stop Game.Time() when game is paused

    end

    this.Triggered = Output; -- Bug #9443: PA forgets Triggered state after ~1 second

end


function CheckSensors()

	for vehicleType, vehicleSize in pairs( Traffic ) do

		local vehicle, _ = Find( First( vehicleType, vehicleSize ) );

		if vehicle then

    		if Authorised( vehicle ) then
    			this.Tooltip = "tooltip_approved_" .. string.lower( vehicleType );
    			return 2; -- true

    		else
    			this.Tooltip = "tooltip_vehicle_approaching";

    		end

    	end

	end

	-- if we get here it means no vehicle found within proximity
	this.Tooltip = "tooltip_no_vehicle_in_proximity";
	return 0; -- false

end

function Authorised( vehicle )

	return Get( vehicle, "Pos.y" ) - OurY <= Proximity and Get( vehicle, "Pos.x" ) == OurX;

end