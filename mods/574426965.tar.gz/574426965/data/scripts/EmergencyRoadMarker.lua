function Create()
    Object.SetProperty(this,"isOpen",true);
    local managers = Object.GetNearbyObjects(this,"TrafficManager",1000);
	local hasManager = false;
	if managers~=nil then
	for n,d in pairs(managers) do
		hasManager = true;
	end
	end
    if hasManager==false then 
		Object.Spawn("TrafficManager",0,0); 
	end
end

local timeTot = -math.random(0,20);
local timeMax = 20;

Interface.AddComponent( this,"toggleOpen", "Button", "Toggle Lane");

function Update(TimePassed)
    timeTot = timeTot + TimePassed;
    if timeTot>timeMax then
		local hasManager = false;
		local managers = Object.GetNearbyObjects(this,"TrafficManager",1000);
		if managers~=nil then
			for n,d in pairs(managers) do
				hasManager = true;
			end
		end
		if hasManager==false then 
			Object.Spawn("TrafficManager",0,0); 
		end
		
        timeTot=0;
    end
end

function toggleOpenClicked()
	if this.isOpen==false then
		Interface.SetCaption(this,"toggleOpen","Close Lane");
		Object.SetProperty(this,"isOpen",true);
		Object.SetProperty(this,"SubType",0);
		this.Sound("_Deployment","SetNone");
	else
		Interface.SetCaption(this,"toggleOpen","Open Lane");
		Object.SetProperty(this,"isOpen",false);
		Object.SetProperty(this,"SubType",1);
		this.Sound("_Deployment","SetNone");
	end
end