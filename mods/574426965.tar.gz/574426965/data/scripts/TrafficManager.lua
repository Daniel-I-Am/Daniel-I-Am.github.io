
function IncrimentCargo()
	--Add to count
	Object.SetProperty(this,"cargocount",tonumber(this.cargocount)+1);
    if this.cargocount>=this.cargoTotal then 
		Object.SetProperty(this,"cargocount",0);
    end
	Object.SetProperty(this,"IC",false);
end


function IncrimentIntake()
	--Add to count
	Object.SetProperty(this,"intakecount",tonumber(this.intakecount)+1);
    if this.intakecount>=this.intakeTotal then 
		Object.SetProperty(this,"intakecount",0);
    end
	Object.SetProperty(this,"II",false);end


function IncrimentEmergency()
	--Add to count
	Object.SetProperty(this,"emergencycount",tonumber(this.emergencycount)+1);
    if this.emergencycount>=this.emergencyTotal then 
		Object.SetProperty(this,"emergencycount",0);
    end
	Object.SetProperty(this,"IE",false);
end

function Create()
	--Initialize current markers to use
    Object.SetProperty(this,"cargocount",-1);
    Object.SetProperty(this,"intakecount",-1);
    Object.SetProperty(this,"emergencycount",-1);
	
	--Set totals to 0 until counted below
	Object.SetProperty(this,"emergencyTotal",0);
	Object.SetProperty(this,"intakeTotal",0);
	Object.SetProperty(this,"cargoTotal",0);
	
	--Incriment functions
    IncrimentCargo();
    IncrimentIntake();
    IncrimentEmergency();
	
	--Trigger variables for incriment functions
    Object.SetProperty(this,"IC",false);
	Object.SetProperty(this,"II",false);
	Object.SetProperty(this,"IE",false);
end

local timeTot = -math.random(0,5);
local timeMax = 1;

function Update(TimePassed)
    timeTot = timeTot + TimePassed;
    if timeTot>timeMax then
        timeTot=0;
		
		--Incriment if trigger variables set
		if this.IC==true then IncrimentCargo(); end
		if this.IE==true then IncrimentEmergency(); end
		if this.II==true then IncrimentIntake(); end
		
		--Count & label markers
		--Cargo
		local markers = Object.GetNearbyObjects(this,"CargoRoadMarker",10000);
		local currentID = 0;
		for n,d in pairs(markers) do
			if n.isOpen==true then
				Object.SetProperty(n,"MarkerID",currentID);
				currentID = currentID + 1;
			end
		end
		Object.SetProperty(this,"cargoTotal",currentID);
		
		--Intake
		markers = Object.GetNearbyObjects(this,"IntakeRoadMarker",10000);
		currentID = 0;
		for n,d in pairs(markers) do
			if n.isOpen==true then
				Object.SetProperty(n,"MarkerID",currentID);
				currentID = currentID + 1;
			end
		end
		Object.SetProperty(this,"intakeTotal",currentID);
		
		--Emergency
		markers = Object.GetNearbyObjects(this,"EmergencyRoadMarker",10000);
		currentID = 0;
		for n,d in pairs(markers) do
			if n.isOpen==true then
				Object.SetProperty(n,"MarkerID",currentID);
				currentID = currentID + 1;
			end
		end
		Object.SetProperty(this,"emergencyTotal",currentID);
	end
end