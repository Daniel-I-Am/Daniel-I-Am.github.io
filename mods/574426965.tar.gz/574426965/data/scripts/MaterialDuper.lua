Interface.AddComponent( this,"copyN", "Button", "Copy Up");
Interface.AddComponent( this,"copyS", "Button", "Copy Down");
Interface.AddComponent( this,"copyW", "Button", "Copy Left");
Interface.AddComponent( this,"copyE", "Button", "Copy Right");

function copyNClicked()
	local x = math.floor(this.Pos.x);
	local y = math.floor(this.Pos.y);
	local cell = World.GetCell(x,y-1);
	cell.Mat = Object.GetMaterial(x,y);
	this.Delete();
end

function copySClicked()
	local x = math.floor(this.Pos.x);
	local y = math.floor(this.Pos.y);
	local cell = World.GetCell(x,y+1);
	cell.Mat = Object.GetMaterial(x,y);
	this.Delete();
end

function copyEClicked()
	local x = math.floor(this.Pos.x);
	local y = math.floor(this.Pos.y);
	local cell = World.GetCell(x+1,y);
	cell.Mat = Object.GetMaterial(x,y);
	this.Delete();
end

function copyWClicked()
	local x = math.floor(this.Pos.x);
	local y = math.floor(this.Pos.y);
	local cell = World.GetCell(x-1,y);
	cell.Mat = Object.GetMaterial(x,y);
	this.Delete();
end