
function Create()
    local roadMarkers = Object.GetNearbyObjects(this,"CargoRoadMarker",10000);
    if roadMarkers~=nil then
        local trafficManager = Object.GetNearbyObjects(this,"TrafficManager",10000);
        if trafficManager~=nil then
		    for n,d in pairs(trafficManager) do
				local roadToUse = n.cargocount;
				Object.SetProperty(n,"IC",true);
				for name,dist in pairs(roadMarkers) do
					if name.isOpen==true then
						if name.MarkerID==roadToUse then
							this.Pos.x = name.Pos.x;
							break;
						end
					end
				end
			end
		end
    end
end

function Update()
	local gates = Object.GetNearbyObjects(this,"SmallRoadGate",5);
	for n,d in pairs(gates) do
		if n.Pos.x == this.Pos.x and n.Pos.y>=this.Pos.y then
			if Object.GetProperty(n,"Open")~=1 then
				Object.SetProperty(this,"Speed",-.2);
			end
		end
	end
	
	for y=1,5,1 do
		local mat = Object.GetMaterial(this.Pos.x,this.Pos.y+y);
		local matl = Object.GetMaterial(this.Pos.x-1,this.Pos.y+y);
		if mat=="ConcreteWall" or mat=="BrickWall" or matl=="ConcreteWall" or matl=="BrickWall" or mat=="PerimeterWall" or mat1=="PerimeterWall" or mat=="Fence" or mat1=="Fence" then
			Object.SetProperty(this,"Speed",-.2);
		end
	end
end