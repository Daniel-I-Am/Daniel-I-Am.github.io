this.Delete();

function Update()
   this.Delete();
end
