
function Create()
    local Stacks = this.GetNearbyObjects( "Stack", 10000 );
 
    for Stack, _ in next, Stacks do
        Stack.Delete();
    end
    
    this.Delete();
end

