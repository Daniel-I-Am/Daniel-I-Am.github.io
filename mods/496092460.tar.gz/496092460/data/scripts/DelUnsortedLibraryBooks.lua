
-- # Deletes all Stackes with the following content
Content = {};
Content["LibraryBookUnsorted"] = true; 



  
function Create()
    local Stacks = this.GetNearbyObjects( "Stack", 10 );
     for Stack, _ in next, Stacks do
        if Content[Stack.Contents] then
            Stack.Delete();
        end
    end    
    this.Delete();
end