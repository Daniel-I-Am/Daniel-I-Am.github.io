-- # Deletes all prisoners of the category specified below
 
function Create()
   local Prisoners = this.GetNearbyObjects( "Prisoner", 10000 );
 
   for Prisoner, _ in next, Prisoners do
     Prisoner.Delete();
   end
 
   this.Delete();
end