local SearchRange = 3;
local DelRange = 1000;


local function GetNextStackContent() -- find nearest applicable candidate
    Game.DebugOut("GetNextStackContent");
    local Stacks = this.GetNearbyObjects( "Stack", SearchRange );
 
    local Found = "";
    local Distance = SearchRange + 1;
 
    for Stack, Range in next, Stacks do
        Game.DebugOut(Range);
        Range = tonumber(Range); -- avoids compare between string and number
        if Range < Distance then
            Distance  = Range;
            Found = Stack.Contents;
        end
    end
    Game.DebugOut("Found: " .. Found);
    return Found;
end

local function DelStacks(StackContent)
    Game.DebugOut("DelStacks");
    local Stacks = this.GetNearbyObjects( "Stack", DelRange );
    for Stack, Range in next, Stacks do
        if Stack.Contents == StackContent then
            Stack.Delete();
        end
    end    
end
  
function Create()
    StackContent = GetNextStackContent();
    if StackContent then DelStacks(StackContent) end
    this.Delete();
end

function Update()
   this.Delete();
end