-- # Deletes all dead entities of the types listed below
 
 
function Create()

    local Prisoners = this.GetNearbyObjects("Prisoner", 10000);

    for Prisoner, _ in next, Prisoners do
        Prisoner.StatusEffects.virus = 0;
    end
    this.Delete();
end