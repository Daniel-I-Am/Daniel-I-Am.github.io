-- # Deletes all Drains 
function Create()
   local Prisoners = this.GetNearbyObjects( "Sprinkler", 10000 );
 
   for Prisoner, _ in next, Prisoners do
     Prisoner.Delete();
   end
 
   this.Delete();
end

function Update()
  this.Delete(); -- Garbage 
end