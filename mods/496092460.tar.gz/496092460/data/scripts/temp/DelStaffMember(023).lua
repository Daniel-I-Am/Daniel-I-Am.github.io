local SearchRange = 3;
local DelRange = 1000;


local function GetNextStackContent() -- find nearest applicable candidate
    Game.DebugOut("GetNextStackContent");
    local Staff = this.GetNearbyObjects( "Entity", SearchRange );
 
    local Found = "";
    local Distance = SearchRange + 1;
 
    for StaffMember, Range in next, Staff do
        Game.DebugOut(Range);
        Range = tonumber(Range); -- avoids compare between string and number
        if Range < Distance then
            Distance  = Range;
            Found = StaffMember;
        end
    end
    Game.DebugOut("Found: " .. Found);
    return Found;
end

local function DelStaff(StackContent)
    Game.DebugOut("DelStacks");
    local Stacks = this.GetNearbyObjects( "Stack", DelRange );
    for Stack, Range in next, Stacks do
        if Stack.Contents == StackContent then
            Stack.Delete();
        end
    end    
end
  
function Create()
    StaffMember = GetNextStackContent();
    if StaffMember then DelStacks(StackContent) end
    -- this.Delete();
end

function Update()
   -- this.Delete();
end