local SearchRange = 3;
local DelRange = 1000;


local function GetNextBoxContent() -- find nearest applicable candidate
    Game.DebugOut("GetNextBoxContent");
    local Boxes = this.GetNearbyObjects( "Box", SearchRange );
 
    local Found = "";
    local Distance = SearchRange + 1;
 
    for Box, Range in next, Boxes do
        Game.DebugOut(Range);
        Range = tonumber(Range); -- avoids compare between string and number
        if Range < Distance then
            Distance  = Range;
            Found = Box.Contents;
        end
    end
    Game.DebugOut("Found: " .. Found);
    return Found;
end

local function DelBoxes(BoxContent)
    Game.DebugOut("DelBoxes");
    local Boxes = this.GetNearbyObjects( "Box", DelRange );
    for Box, Range in next, Boxes do
        if Box.Contents == BoxContent then
            Box.Delete();
        end
    end    
end
  
function Create()
    BoxContent = GetNextBoxContent();
    if BoxContent then DelBoxes(BoxContent) end
    this.Delete();
end

function Update()
   this.Delete();
end