local SearchRange = 3;
local DelRange = 1000;


local function GetNextBoxContent() -- find nearest applicable candidate
    local Boxes = this.GetNearbyObjects( "Box", SearchRange );
 
    local Found;
    local Distance = SearchRange + 1;
 
    for Box, Range in next, Boxes do
        Range = tonumber(Range); -- avoids compare between string and number
        if Range < Distance then
            Distance  = Range;
            Found = Box.Content;
        end
    end
    Game.DebugOut("Found");
    return Found;
end

local function DelBoxes(BoxContent)
    local Boxes = this.GetNearbyObjects( "Box", SearchRange );
    for Box, Range in next, Boxes do
        if Box.Content == BoxContent then
            Box.Delete();
        end
    end    
end
  
function Create()
    BoxContent = GetNextBoxContent();
    if BoxContent then DelBoxes(BoxContent) end
    --this.Delete();
end

function Update()
   --this.Delete
end