
-- # Deletes all boxes with the following content
Content = {};
Content["Bed"] = true; 
Content["Toilet"] = true; 
Content["Table"] = true; 
Content["Bench"] = true; 
Content["ElectricChair"] = true; 
Content["JailDoor"] = true; 
Content["JailDoorLarge"] = true; 
Content["RoadGate"] = true; 
Content["Door"] = true; 
Content["StaffDoor"] = true; 
Content["SolitaryDoor"] = true; 
Content["RemoteDoor"] = true; 
Content["JailBars"] = true; -- found in material.txt, never seen this in game
Content["Window"] = true; 
Content["WindowLarge"] = true; 
Content["Light"] = true; 
Content["Cooker"] = true; 
Content["Fridge"] = true; 
Content["Bin"] = true; 
Content["Sink"] = true; 
Content["ServingTable"] = true; 
Content["ShowerHead"] = true; 
Content["Bookshelf"] = true; 
Content["OfficeDesk"] = true; 
Content["SchoolDesk"] = true; 
Content["FilingCabinet"] = true; 
Content["MedicalBed"] = true; 
Content["MorgueSlab"] = true; 
Content["PowerStation"] = true; 
Content["Capacitor"] = true; 
Content["PowerSwitch"] = true; 
Content["WaterPumpStation"] = true; 
Content["PipeValve"] = true; 
Content["Sprinkler"] = true; 
Content["Drain"] = true; 
Content["MetalDetector"] = true; 
Content["WeightsBench"] = true; 
Content["PhoneBooth"] = true; 
Content["Tv"] = true; 
Content["LargeTv"] = true; -- never seen in game ...
Content["PoolTable"] = true; 
Content["Polaroid"] = true; 
Content["Cctv"] = true; 
Content["CctvMonitor"] = true; 
Content["DoorControlSystem"] = true; 
Content["PhoneMonitor"] = true; 
Content["Servo"] = true; 
Content["DoorTimer"] = true; 
Content["LogicCircuit"] = true; 
Content["LogicBridge"] = true; 
Content["PressurePad"] = true; 
Content["StatusLight"] = true; 
Content["LaundryMachine"] = true; 
Content["WorkshopSaw"] = true; 
Content["WorkshopPress"] = true; 
Content["CarpenterTable"] = true; 
Content["IroningBoard"] = true; 
Content["LaundryBasket"] = true; 
Content["VisitorTable"] = true; 
Content["DogCrate"] = true; 
Content["GuardLocker"] = true; 
Content["WeaponRack"] = true; 
Content["SofaChairSingle"] = true; 
Content["SofaChairDouble"] = true; 
Content["DrinkMachine"] = true; 
Content["ArcadeCabinet"] = true; 
Content["Radio"] = true; 
Content["Altar"] = true; 
Content["Pews"] = true; 
Content["PrayerMat"] = true; 
Content["LibraryBookshelf"] = true; 
Content["SortingTable"] = true; 
Content["ShopFront"] = true; 
Content["ShopShelf"] = true; 

  
function Create()
    local Boxes = this.GetNearbyObjects( "Box", 10000 );
 
    for Box, _ in next, Boxes do
        if Content[Box.Contents] then
            Box.Delete();
        end
    end
    
    this.Delete();
end