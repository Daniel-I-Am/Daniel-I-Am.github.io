local GangId = 2; -- Red gang
local CandidateRange = 3; -- how far to search for potential new leader

local function RemoveCurrentLieutenant() -- find existing lieutenants and demote him
    local Prisoners = this.GetNearbyObjects( "Prisoner", 10000 );

    
    for Prisoner, _ in next, Prisoners do
        -- All gang member to rank soldier = no leader & no lieutenant
        if Prisoner.Gang.Id == GangId then
            Prisoner.Gang.Rank = 1; -- soldier            
        end
    end
end

function Create()
    
    RemoveCurrentLieutenant();
    this.Delete();
end