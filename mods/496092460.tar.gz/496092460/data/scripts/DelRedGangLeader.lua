local GangId = 2; -- Red gang
local CandidateRange = 3; -- how far to search for potential new leader


local function RemoveCurrentLeader() -- find existing leader and demote him
    local Prisoners = this.GetNearbyObjects( "Prisoner", 10000 );

    for Prisoner, _ in next, Prisoners do
        if Prisoner.Gang.Id == GangId and Prisoner.Gang.Rank == "Leader" then
            Prisoner.Gang.Rank = 1; -- soldier
            return; -- just 1 leader should exist ...
        end
    end
end


function Create()
    
    RemoveCurrentLeader();
    this.Delete();
end