
-- # Deletes all Stackes/Items/boxes with the following content
Content = {};
Content["None"] = true; 



  
function Create()
    local Stacks = this.GetNearbyObjects( "Stack", 10000 );
     for Stack, _ in next, Stacks do
        if Content[Stack.Contents] then
            Stack.Delete();
        end
    end    
     local Boxes = this.GetNearbyObjects( "Box", 10000 );
     for Box, _ in next, Boxes do
        if Content[Box.Contents] then
            Box.Delete();
        end
    end    
     local Objects = this.GetNearbyObjects( "None", 10000 );
     for Obj, _ in next, Objects do
        Obj.Delete();
    end    
    this.Delete();
end

function Update()
 this.Delete() -- Garbage
end