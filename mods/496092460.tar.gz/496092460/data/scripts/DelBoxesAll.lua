  
function Create()
    local Boxes = this.GetNearbyObjects( "Box", 10000 );
 
    for Box, _ in next, Boxes do
        Box.Delete();
    end
    this.Delete();
end

