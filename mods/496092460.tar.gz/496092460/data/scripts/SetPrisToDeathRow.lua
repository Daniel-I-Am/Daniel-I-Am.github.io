local CandidateRange = 3; -- how far to search for potential DeathRow

local function GetCandidate() -- find nearest applicable candidate
    local Prisoners = this.GetNearbyObjects( "Prisoner", CandidateRange );
 
    local Candidate;
    local Distance = CandidateRange + 1;
 
    for Prisoner, Range in next, Prisoners do
        Range = tonumber(Range); -- avoids compare between string with number
        if Range < Distance then
            Distance  = Range;
            Candidate = Prisoner;
        end
    end
 
    return Candidate;
end

function Create()
    local Candidate = GetCandidate();
    if Candidate then  
       Candidate.Category = 6; -- Category 6 = Deathrow 
-- # No Acces to Clemency as its saved in Bio ...       
--       local ClemencyChance = math.random(10,40);
--       local ClemencyChance = 1;
--       Game.DebugOut("Clem: " .. ClemencyChance);
--       Candidate.Bio.ClemencyChance = ClemencyChance;
    end
    this.Delete();
 end