local SearchRange = 10000; 

local function SortGang() 
    local Prisoners = this.GetNearbyObjects( "Prisoner", SearchRange );
 
    local Candidate;
    local Distance = SearchRange + 1;
 
    for Prisoner, Range in next, Prisoners do
        GangId = tonumber(Prisoner.Gang.Id);
        if GangId == 2 then 
          if (Prisoner.Category == "MinSec") or (Prisoner.Category == "Normal") or (Prisoner.Category == "MaxSec") then            Game.DebugOut("GangId2 + Category passed");
            Prisoner.Category = 3;
          end
        elseif  GangId == 3 then 
          Game.DebugOut("GangId3: passed");
          if Prisoner.Category == "MinSec" or Prisoner.Category == "Normal" or Prisoner.Category == "MaxSec" then
            Prisoner.Category = 2;
          end
        elseif  GangId == 4 then 
          if Prisoner.Category == "MinSec" or Prisoner.Category == "Normal" or Prisoner.Category == "MaxSec" then
            Prisoner.Category = 1;
          end
        end
        
    end
 
    return Candidate;
end


function Create()
    
    
   SortGang();
   this.Delete();
end