
-- # Deletes all Stackes with the following content
Content = {};
Content["Brick"] = true; 
Content["Concrete"] = true; 
Content["Steel"] = true; 
Content["Bleach"] = true; 
Content["GrassTurf"] = true; 
Content["ElectricalCable"] = true; 
Content["PipeLarge"] = true; 
Content["PipeSmall"] = true; 
Content["BuildingConcrete"] = true; --- ????
Content["Dirt"] = true; 
Content["PavingStone"] = true; 
Content["Grass"] = true; 
Content["LongGrass"] = true; 
Content["Mud"] = true; 
Content["Gravel"] = true; 
Content["Road"] = true; 
Content["Stone"] = true; 
Content["Fence"] = true; 
Content["ConcreteTiles"] = true; 
Content["ConcreteFloor"] = true; 
Content["WoodenFloor"] = true; 
Content["CeramicFloor"] = true; 
Content["MosaicFloor"] = true; 
Content["MetalFloor"] = true; 
Content["Sand"] = true; 
Content["MarbleTiles"] = true; 
Content["WhiteTiles"] = true; 
Content["FancyTiles"] = true; 
Content["ConcreteWall"] = true; 
Content["BrickWall"] = true; 
Content["PerimeterWall"] = true; 
Content["Roof"] = true; 
Content["Water"] = true; 

  
function Create()
    local Stacks = this.GetNearbyObjects( "Stack", 10000 );
 
    for Stack, _ in next, Stacks do
        if Content[Stack.Contents] then
            Stack.Delete();
        end
    end    
    this.Delete();
end