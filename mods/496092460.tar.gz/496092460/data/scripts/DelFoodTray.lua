
-- # Deletes all Stackes with the following content
Content = {};
Content["FoodTray"] = true; 
Content["FoodTrayDirty"] = true; 


  
function Create()
    local Stacks = this.GetNearbyObjects( "Stack", 10000 );
     for Stack, _ in next, Stacks do
        if Content[Stack.Contents] then
            Stack.Delete();
        end
    end    
    this.Delete();
end