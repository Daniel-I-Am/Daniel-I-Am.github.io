-- # Deletes all dead entities of the types listed below
 
local CandidateRange = 1000;
local EntityTypes = 
{ "Workman",
  "TruckDriver",
  "Guard",
  "ArmedGuard",
  "DogHandler",
  "Teacher",
  "SpiritualLeader",
  "ParoleOfficer",
  "ParoleLawyer",
  "AppealsLawyer",
  "AppealsMagistrate",
  "Dog",
  "RiotGuard",
  "Soldier",
  "Prisoner",
  "Doctor",
  "Paramedic",
  "Cook",
  "Gardener",
  "Janitator",
  "Fireman",
  "Avatar",
  "Actor",
  "Visitor",
  "ExecutionWitness",
  "Warden",
  "Chief",
  "Foreman",
  "Psychologist",
  "Accountant",
  "Lawyer"
  }
 
local function GetCandidateType( EntityType )
    local Entities = this.GetNearbyObjects( EntityType, CandidateRange );
    local Candidate;
    local Distance = CandidateRange + 1;
    
    for Entity, Range in next, Entities do
        Range = tonumber(Range);
        if Entity.Damage == 1 and Range < Distance then
            Distance = Range;
            Candidate = Entity;
        end        
    end
    return Candidate, Distance;
end

function GetCandidate()
    local Candidate;
    local Distance = CandidateRange + 1;  
    for _, EntityType in ipairs( EntityTypes ) do
        Entity, Range = GetCandidateType( EntityType );
        Range = tonumber(Range);
        if Distance > Range then
           Candidate = Entity;
           Distance = Range;
        end
    end 
    return Candidate;
end
 
function Create()
    local DeadBody;
    DeadBody = GetCandidate();
    if DeadBody then
       DeadBody.Damage = 0.85;
    end  
    this.Delete();
end

