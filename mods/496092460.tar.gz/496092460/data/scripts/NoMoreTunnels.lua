local count = 0;
local maxcount = 29;
removedTunnels = 0;

function DelTunnels()
    Game.DebugOut("T");
    local Tunnels = this.GetNearbyObjects( "Tunnels", 10000 );
    for Tunnel, _ in next, Tunnels do
        Tunnel.Delete();
        removedTunnels = removedTunnels + 1;
        Game.DebugOut("T");
        this.Tooltip = "Removed Tunnels: " .. removedTunnels;
    end   
end


function Update() 
    if count == maxcount then
       count = 0;
       DelTunnels();
    else
      count = count + 1;
    end


end

  
function Create()
    local found = false;
    local NoTunnels =  this.GetNearbyObjects( "NoMoreTunnels", 10000 );   
    for NoTunnel, _ in next, NoTunnels do
       Game.DebugOut ("xxx");
    end
    
    DelTunnels();
end