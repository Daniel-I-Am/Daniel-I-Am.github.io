local GangId = 3; -- Green gang
local CandidateRange = 10000; -- how far to search for potential new leader

local function GetCandidate() -- find nearest applicable candidate
    local Prisoners = this.GetNearbyObjects( "Prisoner", CandidateRange );
 
    local Candidate;
    local Distance = CandidateRange + 1;
 
    for Prisoner, Range in next, Prisoners do
        Range = tonumber(Range); -- avoids compare between string and number
        if Range < Distance and Prisoner.Gang.Id == GangId then
            Distance  = Range;
            Candidate = Prisoner;
        end
    end
 
    return Candidate;
end

local function RemoveCurrentLeader() -- find existing leader and demote him
    local Prisoners = this.GetNearbyObjects( "Prisoner", 10000 );

    for Prisoner, _ in next, Prisoners do
        if Prisoner.Gang.Id == GangId and Prisoner.Gang.Rank == "Leader" then
            Prisoner.Gang.Rank = 1; -- soldier
            return; -- just 1 leader should exist ...
        end
    end
end

function Create()
    
    
    local Candidate = GetCandidate();
    if Candidate then  
       RemoveCurrentLeader();
        -- promote candidate to gang leader
       Candidate.Gang.Rank = 3; -- leader
    end
 
    this.Delete();
end