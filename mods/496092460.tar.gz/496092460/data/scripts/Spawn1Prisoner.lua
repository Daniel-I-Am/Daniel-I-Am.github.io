function Update()
end

function Create()
   Object.Spawn("Prisoner",this.Pos.x,this.Pos.y);
   this.Delete();
end