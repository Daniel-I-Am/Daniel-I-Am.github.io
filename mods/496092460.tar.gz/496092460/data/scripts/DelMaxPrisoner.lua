-- # Deletes all prisoners of the category specified below
local Category = "MaxSec";
 
function Create()
   local Prisoners = this.GetNearbyObjects( "Prisoner", 10000 );
 
   for Prisoner, _ in next, Prisoners do
     if Prisoner.Category == Category then
        Prisoner.Delete();
     end        
   end
 
   this.Delete();
end