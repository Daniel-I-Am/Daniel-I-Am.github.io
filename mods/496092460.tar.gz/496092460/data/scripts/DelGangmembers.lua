 
function Create()
   local Prisoners = this.GetNearbyObjects( "Prisoner", 10000 );
 
   for Prisoner, _ in next, Prisoners do
     if Prisoner.Gang.Id and tonumber( Prisoner.Gang.Id ) > 1 then
         Prisoner.Delete();
     end
   end      
   this.Delete();
end