function Update()
end

function Create()
   for i=1,10,1 do
     Object.Spawn("Prisoner",this.Pos.x,this.Pos.y);
   end
   this.Delete();
end