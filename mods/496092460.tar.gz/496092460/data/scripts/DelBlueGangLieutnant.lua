local GangId = 4; -- Blue gang
local CandidateRange = 3; -- how far to search for potential new leader

local function GetCandidate() -- find nearest applicable candidate
    local Prisoners = this.GetNearbyObjects( "Prisoner", CandidateRange );
 
    local Candidate;
    local Distance = CandidateRange + 1;
 
    for Prisoner, Range in next, Prisoners do
        Range = tonumber(Range); -- avoids compare between string with number
        if Range < Distance and Prisoner.Gang.Id == GangId then
            Distance  = Range;
            Candidate = Prisoner;
        end
    end
 
    return Candidate;
end

local function RemoveCurrentLeader() -- find existing leader and demote him
    local Prisoners = this.GetNearbyObjects( "Prisoner", 10000 );

    for Prisoner, _ in next, Prisoners do
        if Prisoner.Gang.Id == GangId and Prisoner.Gang.Rank == "Leader" then
            Prisoner.Gang.Rank = 1; -- soldier
            return; -- just 1 leader should exist ...
        end
    end
end

local function RemoveCurrentLieutenant() -- find existing lieutenants and demote him
    local Prisoners = this.GetNearbyObjects( "Prisoner", 10000 );

    for Prisoner, _ in next, Prisoners do
        if Prisoner.Gang.Id == GangId and Prisoner.Gang.Rank == "Lieutenant" then
            Prisoner.Gang.Rank = 1; -- soldier            
        end
    end
end

function Create()
    
    RemoveCurrentLeader();
    local Candidate = GetCandidate();
    if Candidate then  
        -- promote candidate to gang leader
       Candidate.Gang.Rank = 3; -- leader
    else
       -- no leader = no lieutenants
       RemoveCurrentLieutenant();
    end
 
    this.Delete();
end