-- # Deletes all entities of the types listed below
 
local Obj = { "Garbage"};
 
local function DeleteType( Type )
    local Objs = this.GetNearbyObjects( Type, 10000 );
 
    for Objs, _ in next, Objs do
        Objs.Delete();
    end
end
 
function Create()
    for _, Type in ipairs( Obj ) do
        DeleteType( Type );
    end;
 
   this.Delete();
end

function Update()
  this.Delete()
end