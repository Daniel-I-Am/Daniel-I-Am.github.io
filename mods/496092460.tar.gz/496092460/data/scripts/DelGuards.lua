-- # Deletes all entities of the types listed below
 
local EntityTypes = { "Guard", "ArmedGuard", "DogHandler", "Dog" }
 
local function DeleteType( EntityType )
    local Entities = this.GetNearbyObjects( EntityType, 10000 );
 
    for Entity, _ in next, Entities do
        Entity.Delete();
    end
end
 
function Create()
    for _, EntityType in ipairs( EntityTypes ) do
        DeleteType( EntityType );
    end;
 
   this.Delete();
end