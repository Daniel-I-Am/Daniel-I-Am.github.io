local GangId = 2; -- Red gang
local CandidateRange = 10000; -- how far to search for potential new leader

local function GetCandidate() -- find nearest applicable candidate
    local Prisoners = this.GetNearbyObjects( "Prisoner", CandidateRange );
 
    local Candidate;
    local Distance = CandidateRange + 1;
 
    for Prisoner, Range in next, Prisoners do
        Range = tonumber(Range); -- avoids compare between string and number
        if Range < Distance and Prisoner.Gang.Id == GangId and Prisoner.Gang.Rank == "Soldier" then
            Distance  = Range;
            Candidate = Prisoner;
        end
    end
 
    return Candidate;
end



function Create()
    
    
    local Candidate = GetCandidate();
    if Candidate then  
        -- promote candidate to gang lieutenant
       Candidate.Gang.Rank = 2; -- lieutenant
    end
 
    this.Delete();
end