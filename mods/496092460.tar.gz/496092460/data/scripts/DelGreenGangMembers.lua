local GangId = 3; -- Green  gang
local CandidateRange = 1000; -- how far to search for potential new members
local CountCandidates = 10; -- how many Members will be added

local function compRange(Candidate1, Candidate2)
   return Candidate1[1] < Candidate2[1]; -- [1] = Range
end


local function GetCandidates() -- find nearest applicable candidates
    local Prisoners = this.GetNearbyObjects( "Prisoner", CandidateRange );
    local Candidates = {};
    local found=0;
    
   
    for Prisoner, Range in next, Prisoners do
        Range = tonumber(Range); -- avoids compare between string with number
        -- only candidates without gang
        if Prisoner.Gang.Id == GangId and Prisoner.Gang.Rank == "Soldier" then
           table.insert(Candidates,{Range,Prisoner});
        end
    end
    table.sort(Candidates,compRange);
    return Candidates;
end


function Create()   
    local Candidates = GetCandidates();
    local j=0;
    for Index, Candidate in next, Candidates do
       Candidate[2].Gang.Id = 0;
       Candidate[2].Gang.Rank = 0;
       Candidate[2].Gang.Recruitment = 0;
       j = j + 1;
       if j == CountCandidates then
          break;
       end
    end
    this.Delete();
end

