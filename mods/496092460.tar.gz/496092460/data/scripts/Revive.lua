-- # Deletes all dead entities of the types listed below
 
local EntityTypes = 
{ "Workman",
  "TruckDriver",
  "Guard",
  "ArmedGuard",
  "DogHandler",
  "Teacher",
  "SpiritualLeader",
  "ParoleOfficer",
  "ParoleLawyer",
  "AppealsLawyer",
  "AppealsMagistrate",
  "Dog",
  "RiotGuard",
  "Soldier",
  "Prisoner",
  "Doctor",
  "Paramedic",
  "Cook",
  "Gardener",
  "Janitator",
  "Fireman",
  "Avatar",
  "Actor",
  "Visitor",
  "ExecutionWitness",
  "Warden",
  "Chief",
  "Foreman",
  "Psychologist",
  "Accountant",
  "Lawyer"
  }
 
local function ReviveType( EntityType )
    local Entities = this.GetNearbyObjects( EntityType, 10000 );
 
    for Entity, _ in next, Entities do
        if tonumber(Entity.Damage) == 1 then
           Entity.Damage = 0.85;
        end
    end
end
 
function Create()
    for _, EntityType in ipairs( EntityTypes ) do
        ReviveType( EntityType );
    end;
 
   this.Delete();
end