
-- Grants Mod aka "New Grants Mod"
-- Author: Xathz & LDShadowLord
-- Version: v1.9
-- Language: data\language\base-language.txt
-- --------------------------------------
-- Special thanks to:
-- - Adico
-- --------------------------------------

function CreateGrants()

	CreateModInstall();
	CreateBootstrapGrants();
	CreateFirstCellBlockGrant();
	CreateHealthGrant();
	CreateStaffRoom();
	CreateFamilyMatters();
	CreateVisitation();
	CreateBookWormsInmatesGrant();
	CreateExercice();
	CreateWaterLand();	
	CreateLaundromat();
	CreateWorkshop();
	CreateHigherSecurity();
	CreateMetalDetectors();
	-- -------------------------
	
	
	-- -------------------------
	CreateSmallPrison();
	CreateMediumPrison();
	CreateLargePrison();
end

function CreateBootstrapGrants()
	
	Objective.CreateGrant			( "Grant_bootstraps", 40000, 0 )
	
	Objective.CreateGrant			( "Grant_bootstraps_holdingcell", 0, 0 )	
	Objective.SetParent				( "Grant_bootstraps" )
	Objective.RequireRoom			( "HoldingCell", true )
	
	Objective.CreateGrant			( "Grant_bootstraps_shower", 0, 0 )	
	Objective.SetParent				( "Grant_bootstraps" )
	Objective.RequireRoom			( "Shower", true )
	
	Objective.CreateGrant			( "Grant_bootstraps_yard", 0, 0 )
	Objective.SetParent				( "Grant_bootstraps" )
	Objective.RequireRoom			( "Yard", true )

	Objective.CreateGrant			( "Grant_bootstraps_kitchen", 0, 0 )
	Objective.SetParent				( "Grant_bootstraps" )
	Objective.RequireRoom			( "Kitchen", true )
	
	Objective.CreateGrant			( "Grant_bootstraps_canteen", 0, 0 )
	Objective.SetParent				( "Grant_bootstraps" )
	Objective.RequireRoom			( "Canteen", true )

	Objective.CreateGrant			( "Grant_bootstraps_guard", 0, 0 )
	Objective.SetParent				( "Grant_bootstraps" )
	Objective.RequireObjects		( "Guard", 2 )

	Objective.CreateGrant			( "Grant_bootstraps_chef", 0, 0 )
	Objective.SetParent				( "Grant_bootstraps" )
	Objective.RequireObjects		( "Cook", 2 )

	Objective.CreateGrant			( "Grant_Administration", 10000, 0 )
	
	Objective.CreateGrant			( "Grant_Administration_offices", 0, 0 )
	Objective.SetParent				( "Grant_Administration" )
	Objective.RequireRoomsAvailable	( "Office", 2 )
	
	Objective.CreateGrant			( "Grant_Administration_Warden", 0, 0 )
	Objective.SetParent				( "Grant_Administration" )
	Objective.RequireObjects		( "Warden", 1 )
	
	Objective.CreateGrant			( "Grant_Administration_Accountant_Research", 0, 0 )
	Objective.SetParent				( "Grant_Administration" )
	Objective.RequireResearched		( "Finance" )
	
	Objective.CreateGrant			( "Grant_Administration_Accountant", 0, 0 )
	Objective.SetParent				( "Grant_Administration" )
	Objective.RequireObjects		( "Accountant", 1 )
	
end

function CreateFirstCellBlockGrant()

	Objective.CreateGrant			( "Grant_FirstCellBlock", 20000, 10000 )
		
	Objective.CreateGrant			( "Grant_FirstCellBlock_Cells", 0, 0 )
	Objective.SetParent				( "Grant_FirstCellBlock" )	
	Objective.RequireRoomsAvailable	( "Cell", 15 )
	
end

function CreateHealthGrant()

	Objective.CreateGrant			( "Grant_Health", 10000, 10000 )
	
	Objective.CreateGrant			( "Grant_Health_Ward", 0, 0 )
	Objective.SetParent				( "Grant_Health" )
	Objective.RequireRoom			( "MedicalWard", true )
	
	Objective.CreateGrant			( "Grant_Health_Doctors", 0, 0 )
	Objective.RequireObjects		( "Doctor", 2 )
	Objective.SetParent				( "Grant_Health" )
	
	Objective.CreateGrant			( "Grant_Health_Psychologist", 0, 0 )
	Objective.RequireObjects		( "Psychologist", 1 )
	Objective.SetParent				( "Grant_Health" )
	
end

function CreateBookWormsInmatesGrant()


	Objective.CreateGrant			( "Grant_Book_Worms_Inmates", 2000, 1000 )

	Objective.CreateGrant			( "Grant_Book_Worms_Inmates_Commonroom", 0, 700 )
	Objective.SetParent				( "Grant_Book_Worms_Inmates" )
	Objective.RequireRoom			( "CommonRoom", true )
	
	Objective.CreateGrant			( "Grant_Book_Worms_Inmates_Books", 0, 0 )
	Objective.RequireObjects		( "Bookshelf", 3 )
	Objective.SetParent				( "Grant_Book_Worms_Inmates" )
	
	Objective.CreateGrant			( "Grant_Book_Worms_Inmates_Chairs", 0, 0 )
	Objective.RequireObjects		( "Chair", 2 )
	Objective.SetParent				( "Grant_Book_Worms_Inmates" )

end

function CreateHigherSecurity()

	Objective.CreateGrant			( "Grant_Higher_Security", 25000, 5000 )
	
	Objective.CreateGrant			( "Grant_Higher_Secutiry_1", 0, 500 )
	Objective.SetParent				( "Grant_Higher_Security" )
	Objective.RequireResearched		( "Security" )
	
	Objective.CreateGrant			( "Grant_Higher_Secutiry_2", 0, 500 )
	Objective.SetParent				( "Grant_Higher_Security" )
	Objective.RequireResearched		( "Deployment" )
	
	Objective.CreateGrant			( "Grant_Higher_Secutiry_3", 0, 500 )
	Objective.SetParent				( "Grant_Higher_Security" )
	Objective.RequireResearched		( "Cctv" )
	
	Objective.CreateGrant			( "Grant_Higher_Security_Room", 0, 1000 )
	Objective.SetParent				( "Grant_Higher_Security" )
	Objective.RequireRoom			( "Security", true )
	
	Objective.CreateGrant			( "Grant_Higher_Security_Guards", 0, 500 )
	Objective.RequireObjects		( "Guard", 10 )
	Objective.SetParent				( "Grant_Higher_Security" )
	
	Objective.CreateGrant			( "Grant_Higher_Security_CCTV_monitors", 0, 100 )
	Objective.RequireObjects		( "CctvMonitor", 1 )
	Objective.SetParent				( "Grant_Higher_Security" )
	
	Objective.CreateGrant			( "Grant_Higher_Security_CCTV", 0, 500 )
	Objective.RequireObjects		( "Cctv", 3 )
	Objective.SetParent				( "Grant_Higher_Security" )
	
end

function CreateFamilyMatters()

	Objective.CreateGrant			( "Grant_Family_Matters", 10000, 0 )
	
	Objective.CreateGrant			( "Grant_Family_Matters_Phones", 0, 0 )
	Objective.RequireObjects		( "PhoneBooth", 5 )
	Objective.SetParent				( "Grant_Family_Matters" )
	
end

function CreateMetalDetectors()
	
	Objective.CreateGrant			( "Grant_Metal_Detectors", 20000, 5000 )
	
	Objective.CreateGrant			( "Grant_Metal_Detectors_MT", 0, 1000 )
	Objective.RequireObjects		( "MetalDetector", 6 )
	Objective.SetParent				( "Grant_Metal_Detectors" )
	
end

function CreateExercice()

	Objective.CreateGrant			( "Grant_Exercice", 500, 500 )
	
	Objective.CreateGrant			( "Grant_Exercice_1", 0, 500 )
	Objective.SetParent				( "Grant_Exercice" )
	Objective.RequireResearched		( "Maintainance" ) 
	
	Objective.CreateGrant			( "Grant_Exercice_2", 0, 500 )
	Objective.SetParent				( "Grant_Exercice" )
	Objective.RequireResearched		( "GroundsKeeping" ) 
	
	Objective.CreateGrant			( "Grant_Exercice_Benchs", 0, 200 )
	Objective.RequireObjects		( "WeightsBench", 4 )
	Objective.SetParent				( "Grant_Exercice" )
	
end

function CreateSmallPrison()

	Objective.CreateGrant			( "Grant_Small_Prison", 0, 20000 )
	
	Objective.CreateGrant			( "Grant_Small_Prison_Inmates", 0, 0 )
	Objective.RequireObjects		( "Prisoner", 20, "prisoner" )
	Objective.SetParent				( "Grant_Small_Prison" )
	
end
	
function CreateMediumPrison()

	Objective.CreateGrant			( "Grant_Medium_Prison", 0, 50000 )
	
	Objective.CreateGrant			( "Grant_Medium_Prison_Inmates", 0, 0 )
	Objective.RequireObjects		( "Prisoner", 50, "prisoner" )
	Objective.SetParent				( "Grant_Medium_Prison" )
	
end

function CreateLargePrison()

	Objective.CreateGrant			( "Grant_Large_Prison", 0, 100000 )
	
	Objective.CreateGrant			( "Grant_Large_Prison_Inmates", 0, 0 )
	Objective.RequireObjects		( "Prisoner", 50, "prisoner" )
	Objective.SetParent				( "Grant_Large_Prison" )
	
end

function CreateWaterLand()

	Objective.CreateGrant			( "Water_Land", 2500, 1500 )
	
	Objective.CreateGrant			( "Water_land_pump", 0, 5000 )
	Objective.RequireObjects		( "WaterPumpStation", 1)
	Objective.SetParent				( "Water_Land" )
	
	Objective.CreateGrant			( "Water_land_drain", 0, 1000 )
	Objective.RequireObjects		( "Drain", 2)
	Objective.SetParent				( "Water_Land" )
	
	Objective.CreateGrant			( "Water_land_sh", 0, 500 )
	Objective.RequireObjects		( "ShowerHead", 2)
	Objective.SetParent				( "Water_Land" )
	
	Objective.CreateGrant			( "Water_land_room", 0, 500 )
	Objective.SetParent				( "Water_Land" )
	Objective.RequireRoom			( "Shower", true)
	
end

function CreateLaundromat()

	Objective.CreateGrant			( "Grant_Laundromat", 1000, 500 )
	
	Objective.CreateGrant			( "Grant_Laundromat_1", 0, 1000 )
	Objective.SetParent				( "Grant_Laundromat" )
	Objective.RequireResearched		( "PrisonLabour" ) 
	
	Objective.CreateGrant			( "Grant_Laundromat_Machines", 0, 1000 )
	Objective.RequireObjects		( "LaundryMachine", 2 )
	Objective.SetParent				( "Grant_Laundromat" )
	
	Objective.CreateGrant			( "Grant_Laundromat_Baskets", 0, 500 )
	Objective.RequireObjects		( "LaundryBasket", 2 )
	Objective.SetParent				( "Grant_Laundromat" )
	
	Objective.CreateGrant			( "Grant_Laundromat_Room", 0, 500 )
	Objective.SetParent				( "Grant_Laundromat" )
	Objective.RequireRoom			( "Laundry", true)
	
end

function CreateWorkshop()

	Objective.CreateGrant			( "Grant_Workshop", 1000, 500 )
	
	Objective.CreateGrant			( "Grant_Workshop_1", 0, 1000 )
	Objective.SetParent				( "Grant_Workshop" )
	Objective.RequireResearched		( "PrisonLabour" ) 
	
	Objective.CreateGrant			( "Grant_Workshop_Press", 0, 1000 )
	Objective.RequireObjects		( "WorkshopPress", 2 )
	Objective.SetParent				( "Grant_Workshop" )
	
	Objective.CreateGrant			( "Grant_Workshop_Saw", 0, 500 )
	Objective.RequireObjects		( "WorkshopSaw", 2 )
	Objective.SetParent				( "Grant_Workshop" )
	
	Objective.CreateGrant			( "Grant_Workshop_Room", 0, 500 )
	Objective.SetParent				( "Grant_Workshop" )
	Objective.RequireRoom			( "Workshop", true)
	
end

function CreateVisitation()

	Objective.CreateGrant			( "Grant_Visitation", 1000, 500 )
	
	Objective.CreateGrant			( "Grant_Visitation_Table", 0, 500 )
	Objective.RequireObjects		( "VisitorTable", 2 )
	Objective.SetParent				( "Grant_Visitation" )
	
	Objective.CreateGrant			( "Grant_Visitation_Room", 0, 500 )
	Objective.SetParent				( "Grant_Visitation" )
	Objective.RequireRoom			( "Visitation", true)
	
end

function CreateStaffRoom()

	Objective.CreateGrant			( "Grant_StaffRoom", 750, 200 )
	
	Objective.CreateGrant			( "Grant_StaffRoom_Room", 0, 250 )
	Objective.SetParent				( "Grant_StaffRoom" )
	Objective.RequireRoom			( "Staffroom", true)
	
	Objective.CreateGrant			( "Grant_StaffRoom_DrinkMachine", 0, 250 )
	Objective.RequireObjects		( "DrinkMachine", 1 )
	Objective.SetParent				( "Grant_StaffRoom" )
	
	Objective.CreateGrant			( "Grant_StaffRoom_Sofa", 0, 250 )
	Objective.RequireObjects		( "SofaChairDouble", 3 )
	Objective.SetParent				( "Grant_StaffRoom" )

end

function CreateModInstall()
	
	Objective.CreateGrant			( "Grant_Mod_Installed", 2500, 0 )
	
	Objective.CreateGrant			( "Grant_Mod_Installed_1", 0, 0 )
	Objective.RequireRoom			( "Deliveries", 1 )
	Objective.SetParent				( "Grant_Mod_Installed" )
	
end
