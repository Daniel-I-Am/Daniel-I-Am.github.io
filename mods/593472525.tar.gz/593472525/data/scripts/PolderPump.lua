
-- PolderPump.lua
local NumCellsX = nil -- Number of cells on map in horizontal direction
local NumCellsY = nil -- Number of cells on map in vertical direction

local OriginX = nil -- Horizontal position of pump
local OriginY = nil -- Vertical position of pump

local CurrentRadius = 1 -- The size of the square around the pump that will be cleared of water during the next run of Update()
local CurrentCell = nil -- Reference to the cell that is currently being evaluated and if necessary cleared of water

local Time = Game.Time -- Current in-game time (continues running while game is paused!)
local Interval = 3 -- Interval in seconds before the next Update() will run
local Ready = Time() -- Timestamp for the next Update() to run

math.randomseed(Time()) -- Use the in-game time as a seed for the random number generator

function Create()
	-- Uncomment next line for testing purposes: it adds a button that will respawn the pump, also reloading any changed LUA code
	-- this.AddInterfaceComponent("btnRespawn", "Button", "*RESPAWN*")
end

function Update()
	-- The Update() function of every script is called by the game pretty much back-to-back
	-- Also, the game cannot execute any code or update the screen until our code is done
	-- So we have to make sure we don't run all our code every single time Update() is called
	if Time() > Ready then -- If the set Interval hasn't passed yet, this line is the only code being executed
		Echo("PING!")

		if (NumCellsX == nil) or (NumCellsY == nil) then -- Check if cells have been counted yet
			for i = 0, 1000, 1 do -- Get number of cells in horizontal direction
				if next(World.GetCell(i, 0)) == nil then -- Attempting to get a reference to a cell beyond the map boundaries returns nil
					NumCellsX = i
					break
				end
			end
			for i = 0, 1000, 1 do -- Get number of cells in vertical direction
				if next(World.GetCell(0, i)) == nil then -- Attempting to get a reference to a cell beyond the map boundaries returns nil
					NumCellsY = i
					break
				end
			end
			Echo("NumCellsX = " .. NumCellsX)
			Echo("NumCellsY = " .. NumCellsY)
			Ready = Time() + Interval -- Set next time Update() should run
			return -- Exit Update()
		end

		if (OriginX == nil) or (OriginY == nil) then -- Check if pump position has been stored yet (position is not available in Create() unfortunately)
			OriginX = math.floor(this.Pos.x) -- this.Pos.x will return the coords of the exact center of the object, but we only want integers
			OriginY = math.floor(this.Pos.y) -- this.Pos.y will return the coords of the exact center of the object, but we only want integers
			Echo("OriginX = " .. OriginX)
			Echo("OriginY = " .. OriginY)
			Ready = Time() + Interval -- Set next time Update() should run
			return -- Exit Update()
		end

		-- To better understand the next bit of code: each time we're replacing water, we do this in a square centered on the pump
		-- With every pass the distance of the square's borders from the pump increases by 1
		-- We only look at the border of the square, since the border has already passed through the entire inside of the current square
		-- The first for-loop takes care of the top border and the bottom border, both from left to right
		-- The second for-loop takes care of the left border and the right border, from top to bottom, skipping the top and bottom square which were already done by the previous for-loop
		for x = OriginX - CurrentRadius, OriginX + CurrentRadius, 1 do
			for y = OriginY - CurrentRadius, OriginY + CurrentRadius, 2 * CurrentRadius do
				CurrentCell = World.GetCell(x, y)
				if CurrentCell.Mat == "Water" then -- If the current cell contains water ...
					CurrentCell.Mat = "Mud" -- Remove the water, so you end up with mud ...
					CurrentCell.Con = 0 -- Very dirty mud ;)
					Echo("x:" .. x .. " y:" .. y .. " Water replaced with Mud")
					if math.floor(math.random(0, 25)) == 0 then
						Object.Spawn("Rubble", x, y) -- What, did you expect the bottom to be clean?
						Echo("... and some rubble")
					end
				end
			end
		end
		for x = OriginX - CurrentRadius, OriginX + CurrentRadius, 2 * CurrentRadius do -- X coord
			for y = OriginY - (CurrentRadius - 1), OriginY + (CurrentRadius - 1), 1 do -- Y coord
				CurrentCell = World.GetCell(x, y)
				if CurrentCell.Mat == "Water" then -- If the current cell contains water ...
					CurrentCell.Mat = "Mud" -- Remove the water, so you end up with mud ...
					CurrentCell.Con = 0 -- Very dirty mud ;)
					Echo("x:" .. x .. " y:" .. y .. " Water replaced with Mud")
					if math.floor(math.random(0, 25)) == 0 then
						Object.Spawn("Rubble", x, y) -- What, did you expect the bottom to be clean?
						Echo("... and some rubble")
					end
				end
			end
		end

		CurrentRadius = CurrentRadius + 1 -- Increase distance of square's borders to pump

		-- If the distance of the square's borders to the pump exceeds the map boundaries in every direction, we're done
		if (CurrentRadius > OriginX) and (CurrentRadius > OriginY) and (CurrentRadius > (NumCellsX - OriginX - 1)) and (CurrentRadius > (NumCellsY - OriginY - 1)) then
			Echo("CurrentRadius = " .. CurrentRadius)
			-- Reset all variables so if the player has bought new land, the new map size will be taken into account
			NumCellsX = nil
			NumCellsY = nil
			OriginX = nil
			OriginY = nil
			CurrentRadius = 1
			CurrentCell = nil
			collectgarbage("collect") -- Garbage collection to minimize memory usage
			Echo("DONE! ... starting over ;)")
		end

		Ready = Time() + Interval -- Set next time Update() should run
	end
end

function Echo(text)
	-- Uncomment next line to get some debug output in the script debugger (F3)
	-- Game.DebugOut(text)
end

function btnRespawnClicked()
	-- New instance of object makes game read script from disk, including any changes you made since the current object was spawned
	Object.Spawn("PolderPump", this.Pos.x, this.Pos.y) -- spawn a new copy of the pump
	this.Delete() -- delete the current instance of this object
end
