
local timeTot = 0
local Find = Object.GetNearbyObjects

local WaterTank = ""
local FiremanLocker = ""
local Shower = ""

function Create()
	Set("FiremanLockerID","None")
	Set("WaterTankID","None")
	Set("ShowerID","None")
end

function Update(timePassed)
	if timePerUpdate == nil then
		WaterTank = Load(WaterTank,"WaterTank","WaterTankID",10000)
		FiremanLocker = Load(FiremanLocker,"FiremanLocker","FiremanLockerID",10000)
		Shower = Load(Shower,"FiremanShowerHead","ShowerID",10)
		timePerUpdate = 3
	end
	
	timeTot = timeTot + timePassed
	if timeTot >= timePerUpdate then
		timeTot = 0
		
		if not Get("LockerFound") then
			if Get("FiremanLockerID") ~= "None" then
				FiremanLocker = ""
				FiremanLocker =  Load(FiremanLocker,"FiremanLocker","FiremanLockerID",10000)
				if Get("FiremanLockerID") ~= "None" then Set("LockerFound",true) else CheckForNewFiremanLocker() end
			else
				CheckForNewFiremanLocker()
				Set("LockerFound",true)
			end
		elseif not Get("WaterTankFound") then
			if Get("WaterTankID") ~= "None" then
				WaterTank = ""
				WaterTank =  Load(WaterTank,"WaterTank","WaterTankID",10000)
				if Get("WaterTankID") ~= "None" then
					Set("WaterTankFound",true)
				else
					SetOn(FiremanLocker,"HomeUID","None")
					this.Delete()
				end
			else
				SetOn(FiremanLocker,"HomeUID","None")
				this.Delete()
			end
		elseif this.FiremanLockerID ~= "None" and FiremanLocker.SubType == nil then
			print("lost locker, searching new one")
			CheckForNewFiremanLocker()
		elseif this.WaterTankID ~= "None" and WaterTank.SubType == nil then
			print("lost water tank, cleaning up")
			SetOn(FiremanLocker,"HomeUID","None")
			this.Delete()
		end
		
		if this.SubType == 1 and not Get("ClothesOff") then
			print("Creating ChangeClothes job (A)")
			this.NavigateTo(FiremanLocker.Pos.x,FiremanLocker.Pos.y)
			Object.CreateJob(FiremanLocker,"ChangeFiremanClothes"..this.Team.."0")
			Set("ClothesOff",true)
		elseif this.SubType == 2 and not Get("TurnShowerOn") then
			nearbyShowers = Find("FiremanShowerHead",10)
			if next(nearbyShowers) then
				for thatShower, dist in pairs (nearbyShowers) do
					if GetFrom(thatShower,"InUse") == nil then
						SetOn(thatShower,"InUse",true)
						print("turn on shower with id "..thatShower.Id.i)
						Set("ShowerID",thatShower.Id.i)
						Shower = ""
						Shower = Load(Shower,"FiremanShowerHead","ShowerID",10)
						this.NavigateTo(Shower.Pos.x,Shower.Pos.y)
						Object.CreateJob(Shower,"FiremanTurnOnShower"..this.Team.."0")
						break
					end
				end
			end
			nearbyShowers = nil
			Set("TurnShowerOn",true)
		elseif this.SubType == 2 and Get("TurnShowerOn") == true then
			Set("ClothesOff",nil)
			if Get("ShowerID") ~= "None" then
				waterWave = Object.Spawn("Sprinkler",Shower.Pos.x,Shower.Pos.y)
				SetOn(waterWave,"Hidden",true)
				SetOn(waterWave,"Active",true)
				Set("SubType",3)
				print("Creating Shower job")
				this.NavigateTo(Shower.Pos.x,Shower.Pos.y)
				Object.CreateJob(Shower,"FiremanShower"..this.Team.."0")
			else
				Set("SubType",3)
				print("Creating ChangeClothes job (B)")
				this.NavigateTo(FiremanLocker.Pos.x,FiremanLocker.Pos.y)
				Object.CreateJob(FiremanLocker,"ChangeFiremanClothes"..this.Team.."0")
				Set("ShowerDone",true)
			end
		--	Set("ShowerDone",true)	-- gets done in FiremanShowerHead script after job completed
		elseif this.SubType == 3 and Get("ShowerDone") == true and not Get("ClothesOn") then
			SetOn(Shower,"InUse",nil)
			Set("TurnShowerOn",nil)
			Set("ShowerDone",nil)
			print("Creating ChangeClothes job (B)")
		--	this.NavigateTo(FiremanLocker.Pos.x,FiremanLocker.Pos.y)
			Object.CreateJob(FiremanLocker,"ChangeFiremanClothes"..this.Team.."0")
			Set("ClothesOn",true)
		end
	end
end

function CheckForNewFiremanLocker()
	print("checking for new locker")
	nearbyLockers = this.GetNearbyObjects("FiremanLocker",10000)
	if next(nearbyLockers) then
		for thatLocker, dist in pairs(nearbyLockers) do
			if GetFrom(thatLocker,"HomeUID") == "None" then
				SetOn(thatLocker,"HomeUID",Get("HomeUID"))
				SetOn(thatLocker,"WaterTankID",Get("WaterTankID"))
				SetOn(thatLocker,"Team","D")
				SetOn(thatLocker,"Member",0)
				Set("FiremanLockerID",thatLocker.Id.i)
				Set("FiremanLockerX",thatLocker.Pos.x)
				Set("FiremanLockerY",thatLocker.Pos.y)
				Set("SubType",1)
				break
			end
		end
	end
	nearbyLockers = nil
	FiremanLocker = ""
	FiremanLocker = Load(FiremanLocker,"FiremanLocker","FiremanLockerID",10000)
	if Get("FiremanLockerID") == "None" then
		this.Delete()
	end
end


-------------------------------------------------------------------------------------------
-- Helper Functions
------------------------------------------------------------------------------------------- 
function Set(name, value)
    Object.SetProperty(name, value);
end
function Get(name)
    return Object.GetProperty(name);
end
function GetN(name)
    return tonumber(Object.GetProperty(name));
end
function GetFrom(ident, name)
    return Object.GetProperty(ident, name);
end
function SetOn(ident, name, value)
    return Object.SetProperty(ident, name, value);
end
function Print(text)
    Game.DebugOut("Cat", text);
end
function PrintProperty(name)
    local property = Get(name);
    if property == nil then
        property = "nil";
    end    
    
    Print(name .. ": " .. tostring(property));
end
function PropStr(prop)
    return " " .. prop .. ": " .. tostring(Get(prop));
end--]]


-- get the length of a table
function len(tab)
	local count = 0
	for _ in pairs(tab) do
		count = count + 1
	end
	return count
end
--Return Object if in range.
function GetObject(type,id,dist)
	objs = Object.GetNearbyObjects(type,dist or 1)
	for o,d in pairs(objs) do
		 if o.Id.i == id then
		 	return o
		 end
	end
end
--Find Object after Load.
function Load(Object, Type, ID, dist)
    if Object == "" then
        Print(tostring("Trying to load "..Type.." with ID: "..ID));
        TempID = Get(tostring(ID));
        Object = GetObject(Type,TempID,dist);
        Print("Found: "..Type.." Table: "..tostring(Object).." ID: "..TempID);
    end
	if Object == nil then Set(ID,"None") Object = "" end
    return Object
end