
local timeTot = 0
local timePerUpdate = math.random(1,5)+math.random()+math.random()+math.random()+math.random()+math.random()+math.random()
local CurrentDist = 10000
local myLocker = {}

function Create()
	Set("HomeUID",this.Id.i)
end

function Update(timePassed)
	timeTot = timeTot + timePassed
	if timeTot >= timePerUpdate then
		if Get("HomeUID") == this.Id.i then
			CheckForWaterTank()
		else
			this.Delete()
		end
	end
end

function CheckForNearestFiremanLocker(theTank)
	CurrentDist = 10000
	nearbyLockers = Object.GetNearbyObjects(theTank,"FiremanLocker",1000)
	if next(nearbyLockers) then
		for thatLocker, distance in pairs(nearbyLockers) do
			if GetFrom(thatLocker,"HomeUID") == "None" then
				if distance < CurrentDist then
					CurrentDist = distance
					myLocker = thatLocker
				end
			end
		end
	end
end

function CheckForWaterTank()
	if Get("HomeUID") == this.Id.i then
		nearbyTanks = this.GetNearbyObjects("WaterTank",1000)
		if next(nearbyTanks) then
		
			-- check for tanks with 0 Prison firemen linked to it first
			for thatTank, a in pairs(nearbyTanks) do
				if (GetFrom(thatTank,"TimeWarp") ~= nil and GetFrom(thatTank,"HomeUID") ~= nil and GetFrom(thatTank,"Member0ID") == "None" and GetFrom(thatTank,"WaterTankBusy") == false) or (GetFrom(thatTank,"TimeWarp") ~= nil and GetFrom(thatTank,"Member0ID") == "None" and GetFrom(thatTank,"Fireman0Available") == true and GetFrom(thatTank,"WaterTankBusy") == true) then
					newPF0 = Object.Spawn("PrisonFireman"..thatTank.Team.."0",this.Pos.x,this.Pos.y)
					SetOn(thatTank,"Member0ID",newPF0.Id.i)
					
					CheckForNearestFiremanLocker(thatTank)
					if myLocker.SubType == nil then
						newPF0.Delete()
						print("no locker found")
						returnCash = Object.Spawn("CashBack",this.Pos.x,this.Pos.y)
						returnCash.Tooltip = "tooltip_PrisonFiremanNoLocker"
						SetOn(thatTank,"Member0ID","None")
						Set("HomeUID","None")
						break
					end
					
					SetOn(myLocker,"WaterTankID",thatTank.Id.i)
					SetOn(myLocker,"Team",thatTank.Team)
					SetOn(myLocker,"Member",0)
					SetOn(myLocker,"HomeUID",thatTank.HomeUID)
					
					SetOn(newPF0,"HomeUID",thatTank.HomeUID)
					SetOn(newPF0,"Team",thatTank.Team)
					SetOn(newPF0,"WaterTankID",thatTank.Id.i)
					SetOn(newPF0,"WaterTankX",thatTank.Pos.x)
					SetOn(newPF0,"WaterTankY",thatTank.Pos.y)
					SetOn(newPF0,"SubType",1)
					SetOn(newPF0,"FiremanLockerID",myLocker.Id.i)
					SetOn(newPF0,"FiremanLockerX",myLocker.Pos.x)
					SetOn(newPF0,"FiremanLockerY",myLocker.Pos.y)
					SetOn(newPF0,"ShowerSequenceStarted",true)
					newPF0.Tooltip = { "tooltip_PrisonFireman"..thatTank.Team.."0",newPF0.HomeUID,"X" }
					
					SetOn(thatTank,"CheckForNewMembers",true)
					Set("HomeUID",thatTank.HomeUID)
					break
				end
			end
			
			if Get("HomeUID") ~= this.Id.i then
				return
			else
				-- then check for tanks with 1 linked, 2 linked, etcetera.
				for thatTank, b in pairs(nearbyTanks) do
					if (GetFrom(thatTank,"TimeWarp") ~= nil and GetFrom(thatTank,"HomeUID") ~= nil and GetFrom(thatTank,"Member1ID") == "None" and GetFrom(thatTank,"WaterTankBusy") == false) or (GetFrom(thatTank,"TimeWarp") ~= nil and GetFrom(thatTank,"Member1ID") == "None" and GetFrom(thatTank,"Fireman1Available") == true and GetFrom(thatTank,"WaterTankBusy") == true) then
						newPF1 = Object.Spawn("PrisonFireman"..thatTank.Team.."1",this.Pos.x,this.Pos.y)
						SetOn(thatTank,"Member1ID",newPF1.Id.i)
					
						CheckForNearestFiremanLocker(thatTank)
						if myLocker.SubType == nil then
							newPF1.Delete()
							print("no locker found")
							returnCash = Object.Spawn("CashBack",this.Pos.x,this.Pos.y)
							returnCash.Tooltip = "tooltip_PrisonFiremanNoLocker"
							SetOn(thatTank,"Member1ID","None")
							Set("HomeUID","None")
							break
						end
						
						SetOn(myLocker,"WaterTankID",thatTank.Id.i)
						SetOn(myLocker,"Team",thatTank.Team)
						SetOn(myLocker,"Member",1)
						SetOn(myLocker,"HomeUID",thatTank.HomeUID)
						
						SetOn(newPF1,"HomeUID",thatTank.HomeUID)
						SetOn(newPF1,"Team",thatTank.Team)
						SetOn(newPF1,"WaterTankID",thatTank.Id.i)
						SetOn(newPF1,"WaterTankX",thatTank.Pos.x)
						SetOn(newPF1,"WaterTankY",thatTank.Pos.y)
						SetOn(newPF1,"SubType",1)
						SetOn(newPF1,"FiremanLockerID",myLocker.Id.i)
						SetOn(newPF1,"FiremanLockerX",myLocker.Pos.x)
						SetOn(newPF1,"FiremanLockerY",myLocker.Pos.y)
						SetOn(newPF1,"ShowerSequenceStarted",true)
						newPF1.Tooltip = { "tooltip_PrisonFireman"..thatTank.Team.."1",newPF1.HomeUID,"X" }
						
						SetOn(thatTank,"CheckForNewMembers",true)
						Set("HomeUID",thatTank.HomeUID)
						break
					end
				end
			
				if Get("HomeUID") ~= this.Id.i then
					return
				else
					-- this will distribute Prison firemen so all watertanks will get same amount of linked staff
					for thatTank, c in pairs(nearbyTanks) do
						if (GetFrom(thatTank,"TimeWarp") ~= nil and GetFrom(thatTank,"HomeUID") ~= nil and GetFrom(thatTank,"Member2ID") == "None" and GetFrom(thatTank,"WaterTankBusy") == false) or (GetFrom(thatTank,"TimeWarp") ~= nil and GetFrom(thatTank,"Member2ID") == "None" and GetFrom(thatTank,"Fireman2Available") == true and GetFrom(thatTank,"WaterTankBusy") == true) then
							newPF2 = Object.Spawn("PrisonFireman"..thatTank.Team.."2",this.Pos.x,this.Pos.y)
							SetOn(thatTank,"Member2ID",newPF2.Id.i)
					
							CheckForNearestFiremanLocker(thatTank)
							if myLocker.SubType == nil then
								newPF2.Delete()
								print("no locker found")
								returnCash = Object.Spawn("CashBack",this.Pos.x,this.Pos.y)
								returnCash.Tooltip = "tooltip_PrisonFiremanNoLocker"
								SetOn(thatTank,"Member2ID","None")
								Set("HomeUID","None")
								break
							end
							
							SetOn(myLocker,"WaterTankID",thatTank.Id.i)
							SetOn(myLocker,"Team",thatTank.Team)
							SetOn(myLocker,"Member",2)
							SetOn(myLocker,"HomeUID",thatTank.HomeUID)
							
							SetOn(newPF2,"HomeUID",thatTank.HomeUID)
							SetOn(newPF2,"Team",thatTank.Team)
							SetOn(newPF2,"WaterTankID",thatTank.Id.i)
							SetOn(newPF2,"WaterTankX",thatTank.Pos.x)
							SetOn(newPF2,"WaterTankY",thatTank.Pos.y)
							SetOn(newPF2,"SubType",1)
							SetOn(newPF2,"FiremanLockerID",myLocker.Id.i)
							SetOn(newPF2,"FiremanLockerX",myLocker.Pos.x)
							SetOn(newPF2,"FiremanLockerY",myLocker.Pos.y)
							SetOn(newPF2,"ShowerSequenceStarted",true)
							newPF2.Tooltip = { "tooltip_PrisonFireman"..thatTank.Team.."2",newPF2.HomeUID,"X" }
							
							SetOn(thatTank,"CheckForNewMembers",true)
							Set("HomeUID",thatTank.HomeUID)
							break
						end
					end
					
					if Get("HomeUID") ~= this.Id.i then
						return
					else
						for thatTank, d in pairs(nearbyTanks) do
							if (GetFrom(thatTank,"TimeWarp") ~= nil and GetFrom(thatTank,"HomeUID") ~= nil and GetFrom(thatTank,"Member3ID") == "None" and GetFrom(thatTank,"WaterTankBusy") == false) or (GetFrom(thatTank,"TimeWarp") ~= nil and GetFrom(thatTank,"Member3ID") == "None" and GetFrom(thatTank,"Fireman3Available") == true and GetFrom(thatTank,"WaterTankBusy") == true) then
								newPF3 = Object.Spawn("PrisonFireman"..thatTank.Team.."3",this.Pos.x,this.Pos.y)
								SetOn(thatTank,"Member3ID",newPF3.Id.i)
					
								CheckForNearestFiremanLocker(thatTank)
								if myLocker.SubType == nil then
									newPF3.Delete()
									print("no locker found")
									returnCash = Object.Spawn("CashBack",this.Pos.x,this.Pos.y)
									returnCash.Tooltip = "tooltip_PrisonFiremanNoLocker"
									SetOn(thatTank,"Member3ID","None")
									Set("HomeUID","None")
									break
								end
								
								SetOn(myLocker,"WaterTankID",thatTank.Id.i)
								SetOn(myLocker,"Team",thatTank.Team)
								SetOn(myLocker,"Member",3)
								SetOn(myLocker,"HomeUID",thatTank.HomeUID)
								
								SetOn(newPF3,"HomeUID",thatTank.HomeUID)
								SetOn(newPF3,"Team",thatTank.Team)
								SetOn(newPF3,"WaterTankID",thatTank.Id.i)
								SetOn(newPF3,"WaterTankX",thatTank.Pos.x)
								SetOn(newPF3,"WaterTankY",thatTank.Pos.y)
								SetOn(newPF3,"SubType",1)
								SetOn(newPF3,"FiremanLockerID",myLocker.Id.i)
								SetOn(newPF3,"FiremanLockerX",myLocker.Pos.x)
								SetOn(newPF3,"FiremanLockerY",myLocker.Pos.y)
								SetOn(newPF3,"ShowerSequenceStarted",true)
								newPF3.Tooltip = { "tooltip_PrisonFireman"..thatTank.Team.."3",newPF3.HomeUID,"X" }
								
								if GetFrom(WaterTank,"AutoManual") == "-MANUAL-" then
									SetOn(WaterTank,"AutoManual","AUTO")
								end
								SetOn(thatTank,"CheckForNewMembers",true)
								Set("HomeUID",thatTank.HomeUID)
								break
							end
						end
					end
				end
			end
		end
		if this.HomeUID == this.Id.i then
			print("no free WaterTank found")
			Set("HomeUID","None")
			returnCash = Object.Spawn("CashBack",this.Pos.x,this.Pos.y)
			returnCash.Tooltip = "tooltip_PrisonFiremanNoLocker"
		end
	end
end








-------------------------------------------------------------------------------------------
-- Helper Functions
-------------------------------------------------------------------------------------------

function Set(name, value)
    Object.SetProperty(name, value);
end
function Get(name)
    return Object.GetProperty(name);
end
function GetN(name)
    return tonumber(Object.GetProperty(name));
end
function GetFrom(ident, name)
    return Object.GetProperty(ident, name);
end
function SetOn(ident, name, value)
    return Object.SetProperty(ident, name, value);
end
function Print(text)
    Game.DebugOut("Cat", text);
end
function PrintProperty(name)
    local property = Get(name);
    if property == nil then
        property = "nil";
    end    
    
    Print(name .. ": " .. tostring(property));
end
function PropStr(prop)
    return " " .. prop .. ": " .. tostring(Get(prop));
end--]]


-- get the length of a table
function len(tab)
	local count = 0
	for _ in pairs(tab) do
		count = count + 1
	end
	return count
end
--Return Object if in range.
function GetObject(type,id,dist)
	objs = Object.GetNearbyObjects(type,dist or 1)
	for o,d in pairs(objs) do
		 if o.Id.i == id then
		 	return o
		 end
	end
end
--Find Object after Load.
function Load(Object, Type, ID, dist)
    if Object == "" then
        Print(tostring("Trying to load "..Type.." with ID: "..ID));
        TempID = Get(tostring(ID));
        Object = GetObject(Type,TempID,dist);
        Print("Found: "..Type.." Table: "..tostring(Object).." ID: "..TempID);
    end
	if Object == nil then Set(ID,"None") Object = "" end
    return Object
end
