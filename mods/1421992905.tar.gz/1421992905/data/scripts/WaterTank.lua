
local CurrentHour = math.floor(math.mod(World.TimeIndex,1440) /60)
local CurrentMinute = math.floor(math.mod(World.TimeIndex,60))

local timeTot = 0

local timeFireCheck = 0
local timePerFireCheck = 4	-- timePerUpdate gets set to 2 when CheckForReturningFiremen is true, so it will check for fires every 8 minutes!

MySearcher = ""
-- Prison Fireman roaming around and linked to this WaterTank waiting for a GrabHose job
Member0 = ""
Member1 = ""
Member2 = ""
Member3 = ""

-- Real Firemen loaded onto the tank ready to do action or busy on the map fighting fires
Fireman0 = ""
Fireman1 = ""
Fireman2 = ""
Fireman3 = ""

local fireNumber = 0
local fireTLNumber = 0
local fireTRNumber = 0
local fireBLNumber = 0
local fireBRNumber = 0
local FireScanRange = 75	-- the square range covered by the WaterTank, fires beyond will not be taken care off unless WaterTank is set to Manual mode

local CoveredArea = {}

local allFires = {}
local firesTopLeft = {}
local firesTopRight = {}
local firesBottomLeft = {}
local firesBottomRight = {}

local timeInit = 0
local initTimer = math.random(1,5)+math.random()+math.random()+math.random() / 0.75
local Now = 0
local StartingMinute = 0

function Create()
	Set(this,"Tooltip","tooltip_Init_TimeWarp")
	this.SubType = 0
	Set("AutoManual","-MANUAL-")
	Set("CheckForNewMembers",false)
	Set("Member0ID","None")
	Set("Member1ID","None")
	Set("Member2ID","None")
	Set("Member3ID","None")
	Set("myTeam",0.0)
	Set("Fireman0ID","None")
	Set("Fireman1ID","None")
	Set("Fireman2ID","None")
	Set("Fireman3ID","None")
	Set("WaterTankBusy",false)
	Set("Fireman0Available",false)
	Set("Fireman1Available",false)
	Set("Fireman2Available",false)
	Set("Fireman3Available",false)
	Set("FiremanFound",nil)
	Set("Fireman0Deployed",false)
	Set("Fireman1Deployed",false)
	Set("Fireman2Deployed",false)
	Set("Fireman3Deployed",false)
	Set("GrabHose0Done",false)
	Set("GrabHose1Done",false)
	Set("GrabHose2Done",false)
	Set("GrabHose3Done",false)
	Set("FiremanBack",nil)
	Set("CheckForReturningFiremen",false)
	Set("Fireman0BackOrDead",false)
	Set("Fireman1BackOrDead",false)
	Set("Fireman2BackOrDead",false)
	Set("Fireman3BackOrDead",false)
	Set("DeadFiremanNr",0)
	Set("ReturningFiremanNr",0)
	fireNumber = 0
	fireTLNumber = 0
	fireTRNumber = 0
	fireBLNumber = 0
	fireBRNumber = 0
	Set("TLquarterDone",nil)
	Set("TLhalfDone",nil)
	Set("TLthreequarterDone",nil)
	Set("TLwholeDone",nil)
	Set("TRquarterDone",nil)
	Set("TRhalfDone",nil)
	Set("TRthreequarterDone",nil)
	Set("TRwholeDone",nil)
	Set("BLquarterDone",nil)
	Set("BLhalfDone",nil)
	Set("BLthreequarterDone",nil)
	Set("BLwholeDone",nil)
	Set("BRquarterDone",nil)
	Set("BRhalfDone",nil)
	Set("BRthreequarterDone",nil)
	Set("BRwholeDone",nil)
	Set("StopScanningForFire",nil)
	Set("NoFiresFound",nil)
	Set("Fireman0Request",false)
	Set("Fireman1Request",false)
	Set("Fireman2Request",false)
	Set("Fireman3Request",false)
	Set("StopScanningForFire",nil)
	Set("SurroundingFiresCleared",nil)
	Set("NoFiresFound",nil)
	Set("WaterTankSearcherID","None")
end

function Init()
	print("cleaning up...")
	this.SubType = 0
	if this.Fireman0ID ~= "None" then Fireman0.Delete() end
	if this.Fireman1ID ~= "None" then Fireman1.Delete() end
	if this.Fireman2ID ~= "None" then Fireman2.Delete() end
	if this.Fireman3ID ~= "None" then Fireman3.Delete() end
	Set("Fireman0ID","None")
	Set("Fireman1ID","None")
	Set("Fireman2ID","None")
	Set("Fireman3ID","None")
	Set("WaterTankBusy",false)
	Set("Fireman0Available",false)
	Set("Fireman1Available",false)
	Set("Fireman2Available",false)
	Set("Fireman3Available",false)
	Set("FiremanFound",nil)
	Set("Fireman0Deployed",false)
	Set("Fireman1Deployed",false)
	Set("Fireman2Deployed",false)
	Set("Fireman3Deployed",false)
	Set("GrabHose0Done",false)
	Set("GrabHose1Done",false)
	Set("GrabHose2Done",false)
	Set("GrabHose3Done",false)
	Set("FiremanBack",nil)
	Set("CheckForReturningFiremen",false)
	Set("Fireman0BackOrDead",false)
	Set("Fireman1BackOrDead",false)
	Set("Fireman2BackOrDead",false)
	Set("Fireman3BackOrDead",false)
	Set("DeadFiremanNr",0)
	Set("ReturningFiremanNr",0)
	fireNumber = 0
	fireTLNumber = 0
	fireTRNumber = 0
	fireBLNumber = 0
	fireBRNumber = 0
	Set("TLquarterDone",nil)
	Set("TLhalfDone",nil)
	Set("TLthreequarterDone",nil)
	Set("TLwholeDone",nil)
	Set("TRquarterDone",nil)
	Set("TRhalfDone",nil)
	Set("TRthreequarterDone",nil)
	Set("TRwholeDone",nil)
	Set("BLquarterDone",nil)
	Set("BLhalfDone",nil)
	Set("BLthreequarterDone",nil)
	Set("BLwholeDone",nil)
	Set("BRquarterDone",nil)
	Set("BRhalfDone",nil)
	Set("BRthreequarterDone",nil)
	Set("BRwholeDone",nil)
	Set("StopScanningForFire",nil)
	Set("SurroundingFiresCleared",nil)
	Set("NoFiresFound",nil)
	Set("Fireman0Request",false)
	Set("Fireman1Request",false)
	Set("Fireman2Request",false)
	Set("Fireman3Request",false)
	local AvailableHoses = this.GetNearbyObjects("HoseIcon",2)
	for thatHose, dist in pairs(AvailableHoses) do
		if thatHose.HoseNr == theNr then
			thatHose.Delete()
		end
	end
	MySearcher.Delete()
	MySearcher = ""
	Set("WaterTankSearcherID","None")	
	this.Tooltip = { "tooltip_WaterTank",this.HomeUID,"A",this.AutoManual,"B",this.Team,"C",this.myTeam,"X" }
	timePerUpdate = 1+math.random() / myTimeWarpFactor
	print("WaterTank ready for next CallOut...")
end

function Update(timePassed)
	if this.TimeWarp == nil then
		Set(this,"Tooltip","tooltip_init_WaterTank")
		CalculateTimeWarpFactor(timePassed)
		return
	end
	if timePerUpdate == nil then
		if this.HomeUID == nil then
			Set("HomeUID","WaterTank_"..me["id-uniqueId"])
			Set("myTeam",0.0)
			this.Tooltip = "tooltip_init_WaterTank"
		else
			if not Get("SprinklerSpawned") then
				waterWave = Object.Spawn("Sprinkler",this.Pos.x,this.Pos.y)
				waterWave.Hidden = true
				Set("SprinklerSpawned",true)
			end
			this.Tooltip = { "tooltip_WaterTank",this.HomeUID,"A",this.AutoManual,"B",this.Team,"C",this.myTeam,"X" }
			if not this.FiremanBack and this.CheckForReturningFiremen == true then
				if this.AutoManual == "AUTO" then 
					this.Tooltip = { "tooltip_Watertank_FiremenAutoWaitForReturn",this.HomeUID,"A",this.AutoManual,"B",this.Team,"C",fireNumber,"F",this.myTeam,"X",this.ReturningFiremanNr,"Y",this.DeadFiremanNr,"Z" }
				else
					this.Tooltip = { "tooltip_Watertank_FiremenManualWaitForReturn",this.HomeUID,"A",this.AutoManual,"B",this.Team,"C",this.myTeam,"X",this.ReturningFiremanNr,"Y",this.DeadFiremanNr,"Z" }
				end
			end
		end
		
		Interface.AddComponent(this,"toggleShowCoveredFireArea", "Button", "tooltip_button_ShowHideRange",FireScanRange,"X")
		Interface.AddComponent(this,"CaptionSeparatorWaterTank", "Caption", "tooltip_separatorAutoManual")
		Interface.AddComponent(this,"toggleAutoManual", "Button", "tooltip_button_ToggleAutoManual","tooltip_button_"..this.AutoManual,"X")
		
	-------------------------------------------------------------------------------------------
	-- Load References
	-------------------------------------------------------------------------------------------
		print("load my searcher")
		MySearcher = Load(MySearcher,"WaterTankSearcher","WaterTankSearcherID",5)
		
		print("load my team")
		Member0 = Load(Member0,"PrisonFireman"..this.Team.."0","Member0ID",10000); if this.Member0ID ~= "None" then Member0.Tooltip = { "tooltip_PrisonFireman"..this.Team.."0",this.HomeUID,"X" } end
		Member1 = Load(Member1,"PrisonFireman"..this.Team.."1","Member1ID",10000); if this.Member1ID ~= "None" then Member1.Tooltip = { "tooltip_PrisonFireman"..this.Team.."1",this.HomeUID,"X" } end
		Member2 = Load(Member2,"PrisonFireman"..this.Team.."2","Member2ID",10000); if this.Member2ID ~= "None" then Member2.Tooltip = { "tooltip_PrisonFireman"..this.Team.."2",this.HomeUID,"X" } end
		Member3 = Load(Member3,"PrisonFireman"..this.Team.."3","Member3ID",10000); if this.Member3ID ~= "None" then Member3.Tooltip = { "tooltip_PrisonFireman"..this.Team.."3",this.HomeUID,"X" } end
		
		
		print("load firemen")
		Fireman0 = Load(Fireman0,"Fireman","Fireman0ID",10000); if this.Fireman0ID ~= "None" then if this.GrabHose0Done == true then Fireman0.Tooltip = { "tooltip_ActiveFireman"..this.Team.."0",this.HomeUID,"X" } else Fireman0.Tooltip = "tooltip_QueuedFireman" end end
		Fireman1 = Load(Fireman1,"Fireman","Fireman1ID",10000); if this.Fireman0ID ~= "None" then if this.GrabHose1Done == true then Fireman1.Tooltip = { "tooltip_ActiveFireman"..this.Team.."1",this.HomeUID,"X" } else Fireman1.Tooltip = "tooltip_QueuedFireman" end end
		Fireman2 = Load(Fireman2,"Fireman","Fireman2ID",10000); if this.Fireman0ID ~= "None" then if this.GrabHose2Done == true then Fireman2.Tooltip = { "tooltip_ActiveFireman"..this.Team.."2",this.HomeUID,"X" } else Fireman2.Tooltip = "tooltip_QueuedFireman" end end
		Fireman3 = Load(Fireman3,"Fireman","Fireman3ID",10000); if this.Fireman0ID ~= "None" then if this.GrabHose3Done == true then Fireman3.Tooltip = { "tooltip_ActiveFireman"..this.Team.."3",this.HomeUID,"X" } else Fireman3.Tooltip = "tooltip_QueuedFireman" end end
		
		myTimeWarpFactor = this.TimeWarp
		timePerUpdate = 1+math.random() / myTimeWarpFactor
		timePerFireCheck = timePerFireCheck / myTimeWarpFactor
		
		if not this.FiremanBack and this.CheckForReturningFiremen == true then		-- set a random fire check timeout, otherwise all water tanks would suddenly scan at once after a load game
			timeFireCheck = math.random(1,timePerFireCheck)+math.random()+math.random()+math.random() / myTimeWarpFactor
			timePerUpdate = 2+math.random() / myTimeWarpFactor
		end
	end
	-------------------------------------------------------------------------------------------
	
	timeTot = timeTot + timePassed
	if timeTot >= timePerUpdate then
		timeTot = 0
		
		if this.WaterTankBusy == true then								-- a CallOut from the WaterTankSearcher awakened me
			if this.CheckForNewMembers == true then CheckMyMembers() end	-- a new fireman was hired after an active fireman was killed in action, check for the new member
			if not this.FiremanFound then									-- find the firemen which were swapped from the WaterTankSearcher to me
				MySearcher = Load(MySearcher,"WaterTankSearcher","WaterTankSearcherID",5)
				print("find callout fireman")
				if this.myTeam >= 1 then Fireman0 = ""; Fireman0 = Load(Fireman0,"Fireman","Fireman0ID",3) end
				if this.myTeam >= 2 then Fireman1 = ""; Fireman1 = Load(Fireman1,"Fireman","Fireman1ID",3) end
				if this.myTeam >= 3 then Fireman2 = ""; Fireman2 = Load(Fireman2,"Fireman","Fireman2ID",3) end
				if this.myTeam >= 4 then Fireman3 = ""; Fireman3 = Load(Fireman3,"Fireman","Fireman3ID",3) end
				ClearSurroundingFires()				-- removes fires in vicinity of the WaterTank, otherwise the jobs will get Too Dangerous
				Set("FiremanFound",true)
				print("deploy fireman")
				
			else															-- deploy the firemen after GrabHose jobs completed, but let them finish their shower first in case they are called for duty a second time
				if this.Fireman0Deployed == false then if this.Member0ID ~= "None" and GetFrom(Member0,"ShowerSequenceStarted") == false then DeployFireman(Fireman0,0) end end
				if this.Fireman1Deployed == false then if this.Member1ID ~= "None" and GetFrom(Member1,"ShowerSequenceStarted") == false then DeployFireman(Fireman1,1) end end
				if this.Fireman2Deployed == false then if this.Member2ID ~= "None" and GetFrom(Member2,"ShowerSequenceStarted") == false then DeployFireman(Fireman2,2) end end
				if this.Fireman3Deployed == false then if this.Member3ID ~= "None" and GetFrom(Member3,"ShowerSequenceStarted") == false then DeployFireman(Fireman3,3) end end
			end
		else																-- check for deleted or new team members
			if this.Member0ID ~= "None" and Member0.Energy == nil then Set("CheckForNewMembers",true) end
			if this.Member1ID ~= "None" and Member1.Energy == nil then Set("CheckForNewMembers",true) end
			if this.Member2ID ~= "None" and Member2.Energy == nil then Set("CheckForNewMembers",true) end
			if this.Member3ID ~= "None" and Member3.Energy == nil then Set("CheckForNewMembers",true) end
			if this.CheckForNewMembers == true then CheckMyMembers() end
		end
		
						-- check for returning firemen and spawn a Prison Fireman back in place when needed
						-- there is no way to be 100% sure that firemen will return, so keeping it outside the If above should make sure the tank doesn't get stuck at some point

		if not this.FiremanBack and this.CheckForReturningFiremen == true then
			timeFireCheck = timeFireCheck+1
			if timeFireCheck >= timePerFireCheck then	-- checks every ~8 minutes for fires and repositions the firemen to a location near that fire
				timeFireCheck = 0
				if not this.StopScanningForFire and this.AutoManual == "AUTO" then CheckIfFiresAreGone() end
			--	MySearcher.Pos.x = this.Pos.x
			--	MySearcher.Pos.y = this.Pos.y
			end
			if this.Fireman0ID == "None" then Set("Fireman0BackOrDead",true) end
			if this.Fireman1ID == "None" then Set("Fireman1BackOrDead",true) end
			if this.Fireman2ID == "None" then Set("Fireman2BackOrDead",true) end
			if this.Fireman3ID == "None" then Set("Fireman3BackOrDead",true) end
				-- not vanished from the map, not dead yet, but loaded? then it's ok. If all are ok then we leave.
			if this.Fireman0ID ~= "None" and this.GrabHose0Done == true then CheckReturningFireman(Fireman0,0) elseif this.GrabHose0Done == true then Set("Fireman0BackOrDead",true) end
			if this.Fireman1ID ~= "None" and this.GrabHose1Done == true then CheckReturningFireman(Fireman1,1) elseif this.GrabHose1Done == true then Set("Fireman1BackOrDead",true) end
			if this.Fireman2ID ~= "None" and this.GrabHose2Done == true then CheckReturningFireman(Fireman2,2) elseif this.GrabHose2Done == true then Set("Fireman2BackOrDead",true) end
			if this.Fireman3ID ~= "None" and this.GrabHose3Done == true then CheckReturningFireman(Fireman3,3) elseif this.GrabHose3Done == true then Set("Fireman3BackOrDead",true) end
			if this.AutoManual == "AUTO" then 
				this.Tooltip = { "tooltip_Watertank_FiremenAutoWaitForReturn",this.HomeUID,"A",this.AutoManual,"B",this.Team,"C",fireNumber,"F",this.myTeam,"X",this.ReturningFiremanNr,"Y",this.DeadFiremanNr,"Z" }
			else
				this.Tooltip = { "tooltip_Watertank_FiremenManualWaitForReturn",this.HomeUID,"A",this.AutoManual,"B",this.Team,"C",this.myTeam,"X",this.ReturningFiremanNr,"Y",this.DeadFiremanNr,"Z" }
			end
			if this.Fireman0BackOrDead == true and this.Fireman1BackOrDead == true and this.Fireman2BackOrDead == true and this.Fireman3BackOrDead == true then
				print("firemen are all back")
				Init()
			end
		end
		
		
	else		-- keep the firemen below the watertank until they are free to go, to prevent the player from moving the callout too soon and fking up the whole procedure
		if this.WaterTankBusy == true then
			if Fireman0.Energy ~= nil and this.Fireman0Available == true then Fireman0.ClearRouting(); Fireman0.Pos.x = this.Pos.x; Fireman0.Pos.y = this.Pos.y; this.Slot4.i = Fireman0.Id.i; this.Slot4.u = Fireman0.Id.u end
			if Fireman1.Energy ~= nil and this.Fireman1Available == true then Fireman1.ClearRouting(); Fireman1.Pos.x = this.Pos.x; Fireman1.Pos.y = this.Pos.y; this.Slot5.i = Fireman1.Id.i; this.Slot5.u = Fireman1.Id.u end
			if Fireman2.Energy ~= nil and this.Fireman2Available == true then Fireman2.ClearRouting(); Fireman2.Pos.x = this.Pos.x; Fireman2.Pos.y = this.Pos.y; this.Slot6.i = Fireman2.Id.i; this.Slot6.u = Fireman2.Id.u end
			if Fireman3.Energy ~= nil and this.Fireman3Available == true then Fireman3.ClearRouting(); Fireman3.Pos.x = this.Pos.x; Fireman3.Pos.y = this.Pos.y; this.Slot7.i = Fireman3.Id.i; this.Slot7.u = Fireman3.Id.u end
		end
	end
end

function DeployFireman(theFireman,theNr)	-- create GrabHose jobs until the corresponding fireman is deployed, then swap his FireEngine id to make the hose appear below me
	print("function DeployFireman "..theNr)
	if Get("GrabHose"..theNr.."Done") == true then
		print("fireman "..theNr.." deployed")
		Set("Fireman"..theNr.."BackOrDead",false)
	--	SetOn(theFireman,"FireEngine.i",this.Id.i)	-- do this now instead of in SwapGuys to give the firemen a chance to walk a little bit first
	--	SetOn(theFireman,"FireEngine.u",this.Id.u)	-- gets done 
		this.Tooltip = {"tooltip_Watertank_FiremenDeployedNr",this.HomeUID,"A",this.AutoManual,"B",this.Team,"C",this.myTeam,"X" }
		Set("Fireman"..theNr.."Deployed",true)
	elseif Get("GrabHose"..theNr.."Done") == false then
		print("fireman "..theNr.." not deployed yet, issue job GrabHose"..theNr)
		if		 theNr == 0 and Member0.Energy ~= nil then Member0.NavigateTo(this.Pos.x,this.Pos.y)
		elseif	 theNr == 1 and Member1.Energy ~= nil then Member1.NavigateTo(this.Pos.x,this.Pos.y)
		elseif	 theNr == 2 and Member2.Energy ~= nil then Member2.NavigateTo(this.Pos.x,this.Pos.y)
		elseif	 theNr == 3 and Member3.Energy ~= nil then Member3.NavigateTo(this.Pos.x,this.Pos.y)
		end	
		Object.CreateJob(this,"GrabHose"..this.Team..theNr)
	end
end

function JobComplete_InspectWaterTankA3()
	Member3.NavigateTo(this.Pos.x+1.15,this.Pos.y+1.15)
end

function JobComplete_InspectWaterTankB3()
	Member3.NavigateTo(this.Pos.x+1.15,this.Pos.y+1.15)
end

function JobComplete_InspectWaterTankC3()
	Member3.NavigateTo(this.Pos.x+1.15,this.Pos.y+1.15)
end

function JobComplete_InspectWaterTankF3()
	Member3.NavigateTo(this.Pos.x+1.15,this.Pos.y+1.15)
end

function JobComplete_GrabHoseA0()
	SwapGuys(Fireman0,0)
end

function JobComplete_GrabHoseA1()
	SwapGuys(Fireman1,1)
end

function JobComplete_GrabHoseA2()
	SwapGuys(Fireman2,2)
end

function JobComplete_GrabHoseA3()
	SwapGuys(Fireman3,3)
end

function JobComplete_GrabHoseB0()
	SwapGuys(Fireman0,0)
end

function JobComplete_GrabHoseB1()
	SwapGuys(Fireman1,1)
end

function JobComplete_GrabHoseB2()
	SwapGuys(Fireman2,2)
end

function JobComplete_GrabHoseB3()
	SwapGuys(Fireman3,3)
end

function JobComplete_GrabHoseC0()
	SwapGuys(Fireman0,0)
end

function JobComplete_GrabHoseC1()
	SwapGuys(Fireman1,1)
end

function JobComplete_GrabHoseC2()
	SwapGuys(Fireman2,2)
end

function JobComplete_GrabHoseC3()
	SwapGuys(Fireman3,3)
end

function JobComplete_GrabHoseD0()
	SwapGuys(Fireman0,0)
end

function JobComplete_GrabHoseD1()
	SwapGuys(Fireman1,1)
end

function JobComplete_GrabHoseD2()
	SwapGuys(Fireman2,2)
end

function JobComplete_GrabHoseD3()
	SwapGuys(Fireman3,3)
end

function SwapGuys(theFireman,theNr)	-- delete the Prison Fireman, since he can't do what real firemen can do, so we swap him out with the original one and start doing business afterwards
	print("function SwapGuys "..theNr)
	local GuysDoingTheJob = this.GetNearbyObjects("PrisonFireman"..this.Team..theNr,9)
	if next(GuysDoingTheJob) then
		for thatGuy, dist in pairs(GuysDoingTheJob) do
			if Get("Member"..theNr.."ID") == thatGuy.Id.i then		-- check if he is my Prison fireman, or someone else's. allow only my Prison firemen to complete a job
				local tmpLockerID = GetFrom(thatGuy,"FiremanLockerID")
				local tmpLockerX = GetFrom(thatGuy,"FiremanLockerX")
				local tmpLockerY = GetFrom(thatGuy,"FiremanLockerY")
				local tmpDamage = GetFrom(thatGuy,"Damage")
				local tmpEnergy = GetFrom(thatGuy,"Energy")
				thatGuy.Delete()
				local AvailableHoses = this.GetNearbyObjects("HoseIcon",2)
				for thatHose, dist in pairs(AvailableHoses) do
					if thatHose.HoseNr == theNr then
						thatHose.Delete()
					end
				end
				Set("Slot"..theNr..".i",-1)
				Set("Slot"..theNr..".u",-1)
				Set("Fireman"..theNr.."Available",false)
				Set("Member"..theNr.."ID","None")
				Set("GrabHose"..theNr.."Done",true)
				Set("CheckForReturningFiremen",true)
				timeFireCheck = timePerFireCheck-2
				Set("FiremanBack",nil)

				if theNr == 3 and this.AutoManual == "-MANUAL-" then Set("AutoManual","AUTO") end	-- when the crew manager is available, the WaterTank will change to AUTO mode if the tank was set to -MANUAL- due to prior fireman being KIA

									-- revive fireman if he was killed in action and a new fireman grabs a hose, or just unload him when a Prison fireman grabbed a hose
				if		 theNr == 0 then SetOn(Fireman0,"FiremanLockerID",tmpLockerID); SetOn(Fireman0,"FiremanLockerX",tmpLockerX); SetOn(Fireman0,"FiremanLockerY",tmpLockerY); Fireman0.Damage = tmpDamage; Fireman0.Energy = tmpEnergy; Fireman0.SubType = 0; Fireman0.Equipment = 24; Fireman0.Loaded = false; Fireman0.ClearRouting(); Fireman0.NavigateTo(this.Pos.x-1.15,this.Pos.y-1.15); Fireman0.Tooltip = { "tooltip_ActiveFireman"..this.Team.."0",this.HomeUID,"X" }
				elseif	 theNr == 1 then SetOn(Fireman1,"FiremanLockerID",tmpLockerID); SetOn(Fireman1,"FiremanLockerX",tmpLockerX); SetOn(Fireman1,"FiremanLockerY",tmpLockerY); Fireman1.Damage = tmpDamage; Fireman1.Energy = tmpEnergy; Fireman1.SubType = 0; Fireman1.Equipment = 24; Fireman1.Loaded = false; Fireman1.ClearRouting(); Fireman1.NavigateTo(this.Pos.x+1.15,this.Pos.y-1.15); Fireman1.Tooltip = { "tooltip_ActiveFireman"..this.Team.."1",this.HomeUID,"X" }
				elseif	 theNr == 2 then SetOn(Fireman2,"FiremanLockerID",tmpLockerID); SetOn(Fireman2,"FiremanLockerX",tmpLockerX); SetOn(Fireman2,"FiremanLockerY",tmpLockerY); Fireman2.Damage = tmpDamage; Fireman2.Energy = tmpEnergy; Fireman2.SubType = 0; Fireman2.Equipment = 24; Fireman2.Loaded = false; Fireman2.ClearRouting(); Fireman2.NavigateTo(this.Pos.x-1.15,this.Pos.y+1.15); Fireman2.Tooltip = { "tooltip_ActiveFireman"..this.Team.."2",this.HomeUID,"X" }
				elseif	 theNr == 3 then SetOn(Fireman3,"FiremanLockerID",tmpLockerID); SetOn(Fireman3,"FiremanLockerX",tmpLockerX); SetOn(Fireman3,"FiremanLockerY",tmpLockerY); Fireman3.Damage = tmpDamage; Fireman3.Energy = tmpEnergy; Fireman3.SubType = 2; Fireman3.Equipment = 24; Fireman3.Loaded = false; Fireman3.ClearRouting(); Fireman3.NavigateTo(this.Pos.x+1.15,this.Pos.y+1.15); Fireman3.Tooltip = { "tooltip_ActiveFireman"..this.Team.."3",this.HomeUID,"X" }
				end
				break
			end
		end
	else
		Object.CreateJob(this,"GrabHose"..this.Team..theNr)
	end
end

function CheckReturningFireman(theFireman,theNr)	-- checks for returning firemen and spawns a Prison Fireman once the real fireman is back and deleted
	if Get("GrabHose"..theNr.."Done") == true then
		if theFireman.Energy ~= nil and theFireman.Damage < 0.85 then	-- fireman not killed in action
			if theFireman.Loaded then									-- fires gone, fireman is back at the WaterTank, replace him with a normal Prison fireman
				local tmpLockerID = GetFrom(theFireman,"FiremanLockerID")
				local tmpLockerX = GetFrom(theFireman,"FiremanLockerX")
				local tmpLockerY = GetFrom(theFireman,"FiremanLockerY")
				local tmpDamage = GetFrom(theFireman,"Damage")
				local tmpEnergy = GetFrom(theFireman,"Energy")
				SetOn(theFireman,"CarrierId.i",-1)
				SetOn(theFireman,"CarrierId.u",-1)
				SetOn(theFireman,"Loaded",false)
				print("fireman"..theNr.." is back")
				if Get("Fireman"..theNr.."BackOrDead") == false then Set("ReturningFiremanNr",this.ReturningFiremanNr + 1) end
				theFireman.IsPrisonFireman = nil
				Set("Fireman"..theNr.."BackOrDead",true)
				theFireman.Delete()
				theFireman = ""
				newPF = Object.Spawn("PrisonFireman"..this.Team..theNr,this.Pos.x,this.Pos.y)
				SetOn(newPF,"HomeUID",this.HomeUID)
				SetOn(newPF,"Team",this.Team)
				SetOn(newPF,"Energy",tmpEnergy)
				SetOn(newPF,"Damage",tmpDamage)
				SetOn(newPF,"FiremanLockerID",tmpLockerID)
				SetOn(newPF,"FiremanLockerX",tmpLockerX)
				SetOn(newPF,"FiremanLockerY",tmpLockerY)
				SetOn(newPF,"WaterTankID",this.Id.i)
				SetOn(newPF,"WaterTankX",this.Pos.x)
				SetOn(newPF,"WaterTankY",this.Pos.y)
				SetOn(newPF,"SubType",1)
				SetOn(newPF,"ShowerSequenceStarted",true)
				Set("Member"..theNr.."ID",newPF.Id.i)
				Set("Fireman"..theNr.."ID","None")
				if		 theNr == 0 then Member0 = ""; Member0 = Load(Member0,"PrisonFireman"..this.Team.."0","Member0ID",7); Member0.Tooltip = { "tooltip_PrisonFireman"..this.Team.."0",this.HomeUID,"X" }; Member0.NavigateTo(this.Pos.x-1.15,this.Pos.y-1.15)
				elseif	 theNr == 1 then Member1 = ""; Member1 = Load(Member1,"PrisonFireman"..this.Team.."1","Member1ID",7); Member1.Tooltip = { "tooltip_PrisonFireman"..this.Team.."1",this.HomeUID,"X" }; Member1.NavigateTo(this.Pos.x+1.15,this.Pos.y-1.15)
				elseif	 theNr == 2 then Member2 = ""; Member2 = Load(Member2,"PrisonFireman"..this.Team.."2","Member2ID",7); Member2.Tooltip = { "tooltip_PrisonFireman"..this.Team.."2",this.HomeUID,"X" }; Member2.NavigateTo(this.Pos.x-1.15,this.Pos.y+1.15)
				elseif	 theNr == 3 then Member3 = ""; Member3 = Load(Member3,"PrisonFireman"..this.Team.."3","Member3ID",7); Member3.Tooltip = { "tooltip_PrisonFireman"..this.Team.."3",this.HomeUID,"X" }; Member3.NavigateTo(this.Pos.x+1.15,this.Pos.y+1.15)
				end
			else				
				SetOn(theFireman,"FireEngine.i",this.Id.i)	-- do this now instead of in SwapGuys to give the firemen a chance to walk a little bit first
				SetOn(theFireman,"FireEngine.u",this.Id.u)										-- fires gone, fireman walked back to WaterTank, is ready to hop on
				if this.NoFiresFound == true and theFireman.Pos.x >= this.Pos.x-0.75 and theFireman.Pos.x <= this.Pos.x+0.75 and theFireman.Pos.y >= this.Pos.y-0.75 and theFireman.Pos.y <= this.Pos.y+0.75 then
					Set("Slot"..theNr..".i",theFireman.Id.i)
					Set("Slot"..theNr..".u",theFireman.Id.u)
					SetOn(theFireman,"CarrierId.i",this.Id.i)
					SetOn(theFireman,"CarrierId.u",this.Id.u)
					theFireman.Loaded = true
				elseif this.NoFiresFound == true and this.AutoManual == "AUTO" then		-- fires gone, fireman is walking back to the WaterTank
				--	MySearcher.Pos.x = this.Pos.x
				--	MySearcher.Pos.y = this.Pos.y
					if		 theNr == 0 then Fireman0.NavigateTo(this.Pos.x,this.Pos.y)
					elseif	 theNr == 1 then Fireman1.NavigateTo(this.Pos.x,this.Pos.y)
					elseif	 theNr == 2 then Fireman2.NavigateTo(this.Pos.x,this.Pos.y)
					elseif	 theNr == 3 then Fireman3.NavigateTo(this.Pos.x,this.Pos.y)
					end
				end
			end
		else		-- fireman killed in action, replace with a dead dummy, zap fireman back to the WaterTank, so a fresh hired Prison fireman can grab a new hose
			if Get("Fireman"..theNr.."BackOrDead") == false then Set("DeadFiremanNr",this.DeadFiremanNr + 1) end
			print("fireman"..theNr.." is dead")
			deadFireman = Object.Spawn("Fireman",theFireman.Pos.x,theFireman.Pos.y)
			deadFireman.Equipment = 0
			deadFireman.Tooltip = "Toasted bogey"
			deadFireman.Damage = 1
			theFireman.Equipment = 0
			if theNr == 3 then deadFireman.SubType = 3 else deadFireman.SubType = 1 end -- dead crew manager or normal fireman?
			theFireman.SubType = 4		--hide
			theFireman.Damage = 1
			
			SetOn(theFireman,"CarrierId.i",this.Id.i)
			SetOn(theFireman,"CarrierId.u",this.Id.u)
			Set("Slot"..theNr..".i",theFireman.Id.i)
			Set("Slot"..theNr..".u",theFireman.Id.u)
			SetOn(theFireman,"Loaded",true)
			theFireman.Tooltip = "tooltip_QueuedFireman"
			
			if theNr == 3 and this.AutoManual == "AUTO" then Set("AutoManual","-MANUAL-") end	-- when the crew manager dies, the WaterTank will change to manual mode...
			Set("Member"..theNr.."ID","None")
			Set("Fireman"..theNr.."Available",true)
			Set("Fireman"..theNr.."Deployed",false)
			Set("GrabHose"..theNr.."Done",false)
			Set("myTeam",this.myTeam-1)
			Set("Fireman"..theNr.."BackOrDead",true)
		end
	end
end

function CheckIfFiresAreGone()	-- scans every ~8 game minutes for new fires, but only if all currently known fires are gone
	print("....function CheckIfFiresAreGone....")	-- should make this function smaller but it works so why bother
	if not this.StopScanningForFire then
---------------find nearest fires first to start with-------------------------------
		if fireNumber == 0 and not this.TLwholeDone and not this.TRwholeDone and not this.BLwholeDone and not this.BRwholeDone then
			fireNumber = 0
			print("Global: Search request for initial fresh fires within a quarter of my range...")
			allFires = Find("Fire",FireScanRange*0.25) 
			for thatFire, dist in pairs(allFires) do
				fireNumber = fireNumber+1
			end
			if fireNumber <= 1 then
				fireNumber = 0
				print("Global: Area clear")
				print("Global: Search request for initial fresh fires within half my range...")
				allFires = Find("Fire",FireScanRange*0.50) 
				for thatFire, dist in pairs(allFires) do
					fireNumber = fireNumber+1
				end
				if fireNumber <= 1 then
					fireNumber = 0
					print("Global: Area clear")
					print("Global: Search request for initial fresh fires within three quarters of my range...")
					allFires = Find("Fire",FireScanRange*0.75) 
					for thatFire, dist in pairs(allFires) do
						fireNumber = fireNumber+1
					end
					if fireNumber <= 1 then
						fireNumber = 0
						print("Global: Area clear")
						print("Global: Search request for initial fresh fires within my whole range...")
						allFires = Find("Fire",FireScanRange) 
						for thatFire, dist in pairs(allFires) do
							fireNumber = fireNumber+1
						end
					end
				end
			end
		else
		---------------topleft fires check-------------------------------		
			if fireTLNumber <= 1 and this.Fireman0Request == true then
				if not this.TLquarterDone then
					fireTLNumber = 0
					print("Fireman0: Search request for fresh fires within a quarter of TopLeft range...")
					topLeft = Object.Spawn("FiremanAreaCovered",this.Pos.x-(FireScanRange*0.0625),this.Pos.y-(FireScanRange*0.0625))
				--	ShowCoveredArea(topLeft,FireScanRange*0.125,"FiremanTL")		-- just for testing, this eats way too much cpu power to enable it by default
					firesTopLeft = FindFrom(topLeft,"Fire",FireScanRange*0.125)
					for thatFire, dist in pairs(firesTopLeft) do
						fireTLNumber = fireTLNumber+1
					end
					Set("TLquarterDone",true)
				end
				if fireTLNumber <= 1 and not this.TLhalfDone then
					fireTLNumber = 0
					print("Fireman0: Search request for fresh fires within half my TopLeft range...")
					topLeft = Object.Spawn("FiremanAreaCovered",this.Pos.x-(FireScanRange*0.125),this.Pos.y-(FireScanRange*0.125))
				--	ShowCoveredArea(topLeft,FireScanRange*0.25,"FiremanTL")
					firesTopLeft = FindFrom(topLeft,"Fire",FireScanRange*0.25)
					for thatFire, dist in pairs(firesTopLeft) do
						fireTLNumber = fireTLNumber+1
					end
					Set("TLhalfDone",true)
				end
				if fireTLNumber <= 1 and not this.TLthreequarterDone then
					fireTLNumber = 0
					print("Fireman0: Search request for fresh fires within three quarters of my TopLeft range...")
					topLeft = Object.Spawn("FiremanAreaCovered",this.Pos.x-(FireScanRange*0.1875),this.Pos.y-(FireScanRange*0.1875))
				--	ShowCoveredArea(topLeft,FireScanRange*0.375,"FiremanTL")
					firesTopLeft = FindFrom(topLeft,"Fire",FireScanRange*0.375)
					for thatFire, dist in pairs(firesTopLeft) do
						fireTLNumber = fireTLNumber+1
					end
					Set("TLthreequarterDone",true)
				end
				if fireTLNumber <= 1 and not this.TLwholeDone then
					fireTLNumber = 0
					print("Fireman0: Search request for fresh fires within my whole TopLeft range...")
					topLeft = Object.Spawn("FiremanAreaCovered",this.Pos.x-(FireScanRange*0.25),this.Pos.y-(FireScanRange*0.25))
				--	ShowCoveredArea(topLeft,FireScanRange*0.5,"FiremanTL")
					firesTopLeft = FindFrom(topLeft,"Fire",FireScanRange*0.5)
					for thatFire, dist in pairs(firesTopLeft) do
						fireTLNumber = fireTLNumber+1
					end
					Set("TLwholeDone",true)
				end
				Set("Fireman0Request",false)
				if fireTLNumber > 0 and this.Fireman0ID ~= "None" and this.GrabHose0Done == true then
					print("Fireman0: Local fire detected, navigating to new position")
					NavigateToNearestFire(Fireman0,0,allFires,firesTopLeft)
					if this.Fireman1Request == true or this.Fireman2Request == true or this.Fireman3Request == true then
						timeFireCheck = timePerFireCheck
					end
					print("TL: "..fireTLNumber.."   TR: "..fireTRNumber.."   BL: "..fireBLNumber.."   BR: "..fireBRNumber.."   All: "..fireNumber)
					return
				end
			end
		---------------topright fires check-------------------------------	
			if fireTRNumber <= 1 and this.Fireman1Request == true then
				if not this.TRquarterDone then
					fireTRNumber = 0
					print("Fireman1: Search request for fresh fires within a quarter of TopRight range...")
					topRight = Object.Spawn("FiremanAreaCovered",this.Pos.x+(FireScanRange*0.0625),this.Pos.y-(FireScanRange*0.0625))
				--	ShowCoveredArea(topRight,FireScanRange*0.125,"FiremanTR")
					firesTopRight = FindFrom(topRight,"Fire",FireScanRange*0.125)
					for thatFire, dist in pairs(firesTopRight) do
						fireTRNumber = fireTRNumber+1
					end
					Set("TRquarterDone",true)
				end
				if fireTRNumber <= 1 and not this.TRhalfDone then
					fireTRNumber = 0
					print("Fireman1: Search request for fresh fires within half my TopRight range...")
					topRight = Object.Spawn("FiremanAreaCovered",this.Pos.x+(FireScanRange*0.125),this.Pos.y-(FireScanRange*0.125))
				--	ShowCoveredArea(topRight,FireScanRange*0.25,"FiremanTR")
					firesTopRight = FindFrom(topRight,"Fire",FireScanRange*0.25)
					for thatFire, dist in pairs(firesTopRight) do
						fireTRNumber = fireTRNumber+1
					end
					Set("TRhalfDone",true)
				end
				if fireTRNumber <= 1 and not this.TRthreequarterDone then
					fireTRNumber = 0
					print("Fireman1: Search request for fresh fires within three quarters of my TopRight range...")
					topRight = Object.Spawn("FiremanAreaCovered",this.Pos.x+(FireScanRange*0.1875),this.Pos.y-(FireScanRange*0.1875))
				--	ShowCoveredArea(topRight,FireScanRange*0.375,"FiremanTR")
					firesTopRight = FindFrom(topRight,"Fire",FireScanRange*0.375)
					for thatFire, dist in pairs(firesTopRight) do
						fireTRNumber = fireTRNumber+1
					end
					Set("TRthreequarterDone",true)
				end
				if fireTRNumber <= 1 and not this.TRwholeDone then
					fireTRNumber = 0
					print("Fireman1: Search request for fresh fires within my whole TopRight range...")
					topRight = Object.Spawn("FiremanAreaCovered",this.Pos.x+(FireScanRange*0.25),this.Pos.y-(FireScanRange*0.25))
				--	ShowCoveredArea(topRight,FireScanRange*0.5,"FiremanTR")
					firesTopRight = FindFrom(topRight,"Fire",FireScanRange*0.5)
					for thatFire, dist in pairs(firesTopRight) do
						fireTRNumber = fireTRNumber+1
					end
					Set("TRwholeDone",true)
				end
				Set("Fireman1Request",false)
				if fireTRNumber > 0 and this.Fireman1ID ~= "None" and this.GrabHose1Done == true then
					print("Fireman1: Local fire detected, navigating to new position")
					NavigateToNearestFire(Fireman1,1,allFires,firesTopRight)
					if this.Fireman0Request == true or this.Fireman2Request == true or this.Fireman3Request == true then
						timeFireCheck = timePerFireCheck
					end
					print("TL: "..fireTLNumber.."   TR: "..fireTRNumber.."   BL: "..fireBLNumber.."   BR: "..fireBRNumber.."   All: "..fireNumber)
					return
				end
			end
		---------------bottomleft fires check-------------------------------	
			if  fireBLNumber <= 1 and this.Fireman2Request == true then
				if not this.BLquarterDone then
					fireBLNumber = 0
					print("Fireman2: Search request for fresh fires within a quarter of BottomLeft range...")
					bottomLeft = Object.Spawn("FiremanAreaCovered",this.Pos.x-(FireScanRange*0.0625),this.Pos.y+(FireScanRange*0.0625))
				--	ShowCoveredArea(bottomLeft,FireScanRange*0.125,"FiremanBL")
					firesBottomLeft = FindFrom(bottomLeft,"Fire",FireScanRange*0.125)
					for thatFire, dist in pairs(firesBottomLeft) do
						fireBLNumber = fireBLNumber+1
					end
					Set("BLquarterDone",true)
				end
				if fireBLNumber <= 1 and not this.BLhalfDone then
					fireBLNumber = 0
					print("Fireman2: Search request for fresh fires within half my BottomLeft range...")
					bottomLeft = Object.Spawn("FiremanAreaCovered",this.Pos.x-(FireScanRange*0.125),this.Pos.y+(FireScanRange*0.125))
				--	ShowCoveredArea(bottomLeft,FireScanRange*0.25,"FiremanBL")
					firesBottomLeft = FindFrom(bottomLeft,"Fire",FireScanRange*0.25)
					for thatFire, dist in pairs(firesBottomLeft) do
						fireBLNumber = fireBLNumber+1
					end
					Set("BLhalfDone",true)
				end
				if fireBLNumber <= 1 and not this.BLthreequarterDone then
					fireBLNumber = 0
					print("Fireman2: Search request for fresh fires within three quarters of my BottomLeft range...")
					bottomLeft = Object.Spawn("FiremanAreaCovered",this.Pos.x-(FireScanRange*0.1875),this.Pos.y+(FireScanRange*0.1875))
				--	ShowCoveredArea(bottomLeft,FireScanRange*0.375,"FiremanBL")
					firesBottomLeft = FindFrom(bottomLeft,"Fire",FireScanRange*0.375)
					for thatFire, dist in pairs(firesBottomLeft) do
						fireBLNumber = fireBLNumber+1
					end
					Set("BLthreequarterDone",true)
				end
				if fireBLNumber <= 1 and not this.BLwholeDone then
					fireBLNumber = 0
					print("Fireman2: Search request for fresh fires within my whole BottomLeft range...")
					bottomLeft = Object.Spawn("FiremanAreaCovered",this.Pos.x-(FireScanRange*0.25),this.Pos.y+(FireScanRange*0.25))
				--	ShowCoveredArea(bottomLeft,FireScanRange*0.5,"FiremanBL")
					firesBottomLeft = FindFrom(bottomLeft,"Fire",FireScanRange*0.5)
					for thatFire, dist in pairs(firesBottomLeft) do
						fireBLNumber = fireBLNumber+1
					end
					Set("BLwholeDone",true)
				end
				Set("Fireman2Request",false)
				if fireBLNumber > 0 and this.Fireman2ID ~= "None" and this.GrabHose2Done == true then
					print("Fireman2: Local fire detected, navigating to new position")
					NavigateToNearestFire(Fireman2,2,allFires,firesBottomLeft)
					if this.Fireman0Request == true or this.Fireman1Request == true or this.Fireman3Request == true then
						timeFireCheck = timePerFireCheck
					end
					print("TL: "..fireTLNumber.."   TR: "..fireTRNumber.."   BL: "..fireBLNumber.."   BR: "..fireBRNumber.."   All: "..fireNumber)
					return
				end
			end
		---------------bottomright fires check-------------------------------	
			if fireBRNumber <= 1 and this.Fireman3Request == true then
				if not this.BRquarterDone then
					fireBRNumber = 0
					print("Fireman3: Search request for fresh fires within a quarter of BottomRight range...")
					bottomRight = Object.Spawn("FiremanAreaCovered",this.Pos.x+(FireScanRange*0.0625),this.Pos.y+(FireScanRange*0.0625))
				--	ShowCoveredArea(bottomRight,FireScanRange*0.125,"FiremanBR")
					firesBottomRight = FindFrom(bottomRight,"Fire",FireScanRange*0.125)
					for thatFire, dist in pairs(firesBottomRight) do
						fireBRNumber = fireBRNumber+1
					end
					Set("BRquarterDone",true)
				end
				if fireBRNumber <= 1 and not this.BRhalfDone then
					fireBRNumber = 0
					print("Fireman3: Search request for fresh fires within half my BottomRight range...")
					bottomRight = Object.Spawn("FiremanAreaCovered",this.Pos.x+(FireScanRange*0.125),this.Pos.y+(FireScanRange*0.125))
				--	ShowCoveredArea(bottomRight,FireScanRange*0.25,"FiremanBR")
					firesBottomRight = FindFrom(bottomRight,"Fire",FireScanRange*0.25)
					for thatFire, dist in pairs(firesBottomRight) do
						fireBRNumber = fireBRNumber+1
					end
					Set("BRhalfDone",true)
				end
				if fireBRNumber <= 1 and not this.BRthreequarterDone then
					fireBRNumber = 0
					print("Fireman3: Search request for fresh fires within three quarters of my BottomRight range...")
					bottomRight = Object.Spawn("FiremanAreaCovered",this.Pos.x+(FireScanRange*0.1875),this.Pos.y+(FireScanRange*0.1875))
				--	ShowCoveredArea(bottomRight,FireScanRange*0.375,"FiremanBR")
					firesBottomRight = FindFrom(bottomRight,"Fire",FireScanRange*0.375)
					for thatFire, dist in pairs(firesBottomRight) do
						fireBRNumber = fireBRNumber+1
					end
					Set("BRthreequarterDone",true)
				end
				if fireBRNumber <= 1 and not this.BRwholeDone then
					fireBRNumber = 0
					print("Fireman3: Search request for fresh fires within my whole BottomRight range...")
					bottomRight = Object.Spawn("FiremanAreaCovered",this.Pos.x+(FireScanRange*0.25),this.Pos.y+(FireScanRange*0.25))
				--	ShowCoveredArea(bottomRight,FireScanRange*0.5,"FiremanBR")
					firesBottomRight = FindFrom(bottomRight,"Fire",FireScanRange*0.5)
					for thatFire, dist in pairs(firesBottomRight) do
						fireBRNumber = fireBRNumber+1
					end
					Set("BRwholeDone",true)
				end
				Set("Fireman3Request",false)
				if fireBRNumber > 0 and this.Fireman3ID ~= "None" and this.GrabHose3Done == true then
					print("Fireman3: Local fire detected, navigating to new position")
					NavigateToNearestFire(Fireman3,3,allFires,firesBottomRight)
					if this.Fireman0Request == true or this.Fireman1Request == true or this.Fireman2Request == true then
						timeFireCheck = timePerFireCheck
					end
					print("TL: "..fireTLNumber.."   TR: "..fireTRNumber.."   BL: "..fireBLNumber.."   BR: "..fireBRNumber.."   All: "..fireNumber)
					return
				end
			end
	---------------all fires check-------------------------------
			if fireNumber <= 1 and (this.TLwholeDone == true or this.TRwholeDone == true or this.BLwholeDone == true or this.BRwholeDone == true) then
				fireNumber = 0
				print("Global: Search request for fresh fires within a quarter of my range...")
				allFires = Find("Fire",FireScanRange*0.25) 
				for thatFire, dist in pairs(allFires) do
					fireNumber = fireNumber+1
				end
				if fireNumber <= 1 then
					fireNumber = 0
					print("Global: Area clear")
					print("Global: Search request for fresh fires within half my range...")
					allFires = Find("Fire",FireScanRange*0.50) 
					for thatFire, dist in pairs(allFires) do
						fireNumber = fireNumber+1
					end
					if fireNumber <= 1 then
						fireNumber = 0
						print("Global: Area clear")
						print("Global: Search request for fresh fires within three quarters of my range...")
						allFires = Find("Fire",FireScanRange*0.75) 
						for thatFire, dist in pairs(allFires) do
							fireNumber = fireNumber+1
						end
						if fireNumber <= 1 then
							fireNumber = 0
							print("Global: Area clear")
							print("Global: Search request for fresh fires within my whole range...")
							allFires = Find("Fire",FireScanRange) 
							for thatFire, dist in pairs(allFires) do
								fireNumber = fireNumber+1
							end
						end
					end
				end
			end
			print("TL: "..fireTLNumber.."   TR: "..fireTRNumber.."   BL: "..fireBLNumber.."   BR: "..fireBRNumber.."   All: "..fireNumber)
		end
		if fireTLNumber > 0 or fireTRNumber > 0 or fireBLNumber > 0 or fireBRNumber > 0 or fireNumber > 0 then
			timePerUpdate = 2+math.random() / myTimeWarpFactor
			Set("NoFiresFound",false)
			print("Global: Fire detected, navigating all firemen to new position")
			if this.Fireman0ID ~= "None" and this.GrabHose0Done == true then NavigateToNearestFire(Fireman0,0,allFires,firesTopLeft) end
			if this.Fireman1ID ~= "None" and this.GrabHose1Done == true then NavigateToNearestFire(Fireman1,1,allFires,firesTopRight) end
			if this.Fireman2ID ~= "None" and this.GrabHose2Done == true then NavigateToNearestFire(Fireman2,2,allFires,firesBottomLeft) end
			if this.Fireman3ID ~= "None" and this.GrabHose3Done == true then NavigateToNearestFire(Fireman3,3,allFires,firesBottomRight) end
		else
			print("Global: Area clear")
			print("Global: No more fires found within range, returning all firemen")
			Object.CancelJob(this,"GrabHoseA0")	-- cancel any pending jobs, they are no longer needed
			Object.CancelJob(this,"GrabHoseA1")
			Object.CancelJob(this,"GrabHoseA2")
			Object.CancelJob(this,"GrabHoseA3")
			Object.CancelJob(this,"GrabHoseB0")
			Object.CancelJob(this,"GrabHoseB1")
			Object.CancelJob(this,"GrabHoseB2")
			Object.CancelJob(this,"GrabHoseB3")
			Object.CancelJob(this,"GrabHoseC0")
			Object.CancelJob(this,"GrabHoseC1")
			Object.CancelJob(this,"GrabHoseC2")
			Object.CancelJob(this,"GrabHoseC3")
			Object.CancelJob(this,"GrabHoseD0")
			Object.CancelJob(this,"GrabHoseD1")
			Object.CancelJob(this,"GrabHoseD2")
			Object.CancelJob(this,"GrabHoseD3")
			timePerUpdate = 1+math.random() / myTimeWarpFactor
			Set("NoFiresFound",true)
			Set("StopScanningForFire",true)
			if this.Fireman0ID ~= "None" and this.GrabHose0Done == true then Fireman0.NavigateTo(this.Pos.x,this.Pos.y) end
			if this.Fireman1ID ~= "None" and this.GrabHose1Done == true then Fireman1.NavigateTo(this.Pos.x,this.Pos.y) end
			if this.Fireman2ID ~= "None" and this.GrabHose2Done == true then Fireman2.NavigateTo(this.Pos.x,this.Pos.y) end
			if this.Fireman3ID ~= "None" and this.GrabHose3Done == true then Fireman3.NavigateTo(this.Pos.x,this.Pos.y) end
		end
	end
end

function NavigateToNearestFire(theEntity,theNr,allFires,localFires)	-- calculates which fire is nearest to the corresponding fireman, and sends him over there
	local Done = false
	local retryCounter = 0
	local rndFire = 0
	local CurrentDist = 10000
	local localFireNr = 0
	local theDistance = 0
	if theNr == 0 then localFireNr = fireTLNumber
	elseif theNr == 1 then localFireNr = fireTRNumber
	elseif theNr == 2 then localFireNr = fireBLNumber
	elseif theNr == 3 then localFireNr = fireBRNumber
	end
	while Done == false do
		if localFireNr > 0 then
			CurrentDist = 10000
			for thatFire, dist in pairs(localFires) do
				if thatFire.SubType == nil then
					localFires[thatFire] = nil
					localFireNr = localFireNr - 1
				--	print("localFireNr:"..localFireNr)
				else
					theDistance = FindDistance(theEntity.Pos.x,theEntity.Pos.y,thatFire.Pos.x,thatFire.Pos.y)
					if tonumber(theDistance) <= CurrentDist then
						CurrentDist = theDistance
						myFire = thatFire
						print("Fireman"..theNr..": Filtering nearest local fire: "..myFire.Pos.x.."   "..myFire.Pos.y.." distance: "..theDistance)
					end
				end
			end
			--print("localFireNr:"..localFireNr)
			--print("Sending fireman"..theNr.." to local fire: "..myFire.Pos.x.."   "..myFire.Pos.y.." distance: "..theDistance)
			if theNr == 0 then fireTLNumber = localFireNr
			elseif theNr == 1 then fireTRNumber = localFireNr
			elseif theNr == 2 then fireBLNumber = localFireNr
			elseif theNr == 3 then fireBRNumber = localFireNr
			end
			if localFireNr == 0 then
				print("Fireman"..theNr..": Area clear")
				print("Fireman"..theNr..": No dedicated local fires found, requesting new search at wider range")
				if theNr == 0 then Set("Fireman0Request",true)
				elseif theNr == 1 then Set("Fireman1Request",true)
				elseif theNr == 2 then Set("Fireman2Request",true)
				elseif theNr == 3 then Set("Fireman3Request",true)
				end
				Done = true
				return
			end
		else
		--	print("Fireman"..theNr..": Area clear")
		--	print("Fireman"..theNr..": No dedicated local fires found")
			if theNr == 0 then Set("Fireman0Request",true); Fireman0.SubType = 1
			elseif theNr == 1 then Set("Fireman1Request",true); Fireman1.SubType = 1
			elseif theNr == 2 then Set("Fireman2Request",true); Fireman2.SubType = 1
			elseif theNr == 3 then Set("Fireman3Request",true); Fireman3.SubType = 3
			end
			if fireNumber > 0 then
				CurrentDist = 10000
				for thatFire, dist in pairs(allFires) do
					if thatFire.SubType == nil then
						allFires[thatFire] = nil
						fireNumber = fireNumber-1
					--	print("fireNumber:"..fireNumber)
					else
						theDistance = FindDistance(theEntity.Pos.x,theEntity.Pos.y,thatFire.Pos.x,thatFire.Pos.y)
						if tonumber(theDistance) <= CurrentDist then
							CurrentDist = theDistance
							myFire = thatFire
							print("Fireman"..theNr..": Filtering nearest global fire "..myFire.Pos.x.."   "..myFire.Pos.y.." distance: "..theDistance)
						end
					end
				end
			--	print("fireNumber:"..fireNumber)
			--	print("Sending fireman"..theNr.." to global fire: "..myFire.Pos.x.."   "..myFire.Pos.y.." distance: "..theDistance)
			end
		end
		if myFire == nil then
			fireNumber = 0
			timeFireCheck = timePerFireCheck
			print("Fireman"..theNr..": Area clear")
			print("Fireman"..theNr..": No more known fires within range")
			Done = true
			return
		else
			local smk = 0; localSmoke = FindFrom(theEntity,"SmokeGenerator",12); for thatSmoke, dist in pairs(localSmoke) do smk = smk+1; thatSmoke.Delete(); end; print("smoke deleted: "..smk); localSmoke = nil	-- get rid of some nearby smoke since it slows down the game.
			Set("NoFiresFound",false)	-- we have a fire, move the fireman to a spot close to it which is not a wall or water
			local moveToX = myFire.Pos.x
			local moveToY = myFire.Pos.y
			if this.Pos.x > moveToX then moveToX = moveToX+math.random(2,5) else moveToX = moveToX-math.random(2,5) end
			if this.Pos.y > moveToY then moveToY = moveToY+math.random(2,5) else moveToY = moveToY-math.random(2,5) end
			if moveToX < 1 then moveToX = 1 end
			if moveToY < 1 then moveToY = 1 end
			local tmpCell = World.GetCell(math.floor(moveToX),math.floor(moveToY))
			if tmpCell.Mat == "BrickWall" or tmpCell.Mat == "ConcreteWall" or tmpCell.Mat == "PerimeterWall" or tmpCell.Mat == "Fence" or tmpCell.Mat == "Water" then
		--		print("tmpCell.Mat: "..tmpCell.Mat..", retrying...")
				Done = false
			else
		--		print("covered spawned, moving entity to "..moveToX.." "..moveToY)
				local newCovered = Object.Spawn("FiremanTLAreaCovered",moveToX,moveToY)	-- spawn a little temporary indicator on the floor where the fireman will go to (it deletes itself again)
				print("Fireman"..theNr..": moving to x: "..moveToX.." y: "..moveToY)
				theEntity.NavigateTo(moveToX,moveToY)
				Done = true
			end
			myFire = nil
		end
		
		retryCounter = retryCounter+1			-- to prevent looping, we give this While 10 chances to find a suitable spot on the map to walk to
	--	print("retryCounter: "..retryCounter)
		if retryCounter >= 10 then
			print("FAIL")
			fireNumber = 0
			timeFireCheck = timePerFireCheck
			if		 theNr == 1 then theEntity.NavigateTo(theEntity.Pos.x-1.15,theEntity.Pos.y-1.15)	-- when failed, the Firemen will walk counterclockwise around the WaterTank :)
			elseif	 theNr == 2 then theEntity.NavigateTo(theEntity.Pos.x+1.15,theEntity.Pos.y-1.15)
			elseif	 theNr == 3 then theEntity.NavigateTo(theEntity.Pos.x-1.15,theEntity.Pos.y+1.15)
			elseif	 theNr == 0 then theEntity.NavigateTo(theEntity.Pos.x+1.15,theEntity.Pos.y+1.15)
			end
			Done = true
		end
	end
end


function CheckMyMembers()
	print("Checking for TeamMembers")
	Member0 = ""
	Member1 = ""
	Member2 = ""
	Member3 = ""
	Member0 = Load(Member0,"PrisonFireman"..this.Team.."0","Member0ID",10000); if this.Member0ID ~= "None" then Member0.Tooltip = { "tooltip_PrisonFireman"..this.Team.."0",this.HomeUID,"X" } end
	Member1 = Load(Member1,"PrisonFireman"..this.Team.."1","Member1ID",10000); if this.Member1ID ~= "None" then Member1.Tooltip = { "tooltip_PrisonFireman"..this.Team.."1",this.HomeUID,"X" } end
	Member2 = Load(Member2,"PrisonFireman"..this.Team.."2","Member2ID",10000); if this.Member2ID ~= "None" then Member2.Tooltip = { "tooltip_PrisonFireman"..this.Team.."2",this.HomeUID,"X" } end
	Member3 = Load(Member3,"PrisonFireman"..this.Team.."3","Member3ID",10000); if this.Member3ID ~= "None" then Member3.Tooltip = { "tooltip_PrisonFireman"..this.Team.."3",this.HomeUID,"X" } end
	Set("myTeam",0)
	for i=0,3 do
		if Get("Member"..i.."ID") ~= "None" then
			Set("myTeam",this.myTeam+1)
		end
	end
	if this.WaterTankBusy == true and this.AutoManual == "AUTO" then
		timeFireCheck = timePerFireCheck
	end
	this.SetInterfaceCaption("toggleAutoManual", "tooltip_button_ToggleAutoManual","tooltip_button_"..this.AutoManual,"X")
	this.Tooltip = { "tooltip_WaterTank",this.HomeUID,"A",this.AutoManual,"B",this.Team,"C",this.myTeam,"X" }
	Set("CheckForNewMembers",false)
end

function ClearSurroundingFires()
	if not Get("SurroundingFiresCleared") then
		local surroundingFires = Find("Fire",12)
		if next(surroundingFires) then
			for thatFire, dist in pairs(surroundingFires) do
				thatFire.Delete()
			end
			Object.CancelJob(this,"GrabHoseA0")	-- cancel the pending jobs, since they might have been Too Dangerous
			Object.CancelJob(this,"GrabHoseA1")	-- they get issued again by DeployFireman() anyway
			Object.CancelJob(this,"GrabHoseA2")
			Object.CancelJob(this,"GrabHoseA3")
			Object.CancelJob(this,"GrabHoseB0")
			Object.CancelJob(this,"GrabHoseB1")
			Object.CancelJob(this,"GrabHoseB2")
			Object.CancelJob(this,"GrabHoseB3")
			Object.CancelJob(this,"GrabHoseC0")
			Object.CancelJob(this,"GrabHoseC1")
			Object.CancelJob(this,"GrabHoseC2")
			Object.CancelJob(this,"GrabHoseC3")
			Object.CancelJob(this,"GrabHoseD0")
			Object.CancelJob(this,"GrabHoseD1")
			Object.CancelJob(this,"GrabHoseD2")
			Object.CancelJob(this,"GrabHoseD3")
		end
		Set("SurroundingFiresCleared",true)
	end
end












-------------------------------------------------------------------------------------------
-- Helper Functions
------------------------------------------------------------------------------------------- 

function CalculateTimeWarpFactor(timePassed)
	if timeInit > initTimer then
	
		if timePerUpdate == nil then
			Now = math.floor(math.mod(World.TimeIndex,60))
			if not StartCountdown then
				if Now > StartingMinute then
					this.SubType = 2		-- display a red stopwatch, indicating calculation has started
					StartingMinute = Now
					StartCountdown = true
					this.Tooltip = {"tooltip_Init_TimeWarpB",StartingMinute,"A",StartingMinute+5,"B",Now,"C",0,"D" }
				end
			else
				timeTot=timeTot+timePassed
				this.Tooltip = {"tooltip_Init_TimeWarpB",StartingMinute,"A",StartingMinute+5,"B",Now,"C",timeTot,"D" }
				if Now >= StartingMinute+5 then
					if timeTot > 9 then		-- the result should be around 9.99 for large map
						myTimeWarpFactor = 0.5
						this.SubType = 3
						this.Tooltip = {"tooltip_Init_TimeWarpC",StartingMinute,"A",StartingMinute+5,"B",Now,"C",timeTot,"D","Large","E",myTimeWarpFactor,"F" }
					elseif timeTot > 6 then	-- the result should be around 6.66 for medium map
						myTimeWarpFactor = 0.75
						this.SubType = 4
						this.Tooltip = {"tooltip_Init_TimeWarpC",StartingMinute,"A",StartingMinute+5,"B",Now,"C",timeTot,"D","Medium","E",myTimeWarpFactor,"F" }
					else					-- the result should be around 5 for small map
						myTimeWarpFactor = 1
						this.SubType = 5
						this.Tooltip = {"tooltip_Init_TimeWarpC",StartingMinute,"A",StartingMinute+5,"B",Now,"C",timeTot,"D","Small","E",myTimeWarpFactor,"F" }
					end
					timeTot = 0
					timePerUpdate = 3 / myTimeWarpFactor		-- wait a few to display the outcome
				end
			end
		else
			timeTot = timeTot+timePassed
			if timeTot > timePerUpdate then		-- make the tiles surrounding the WaterTank into ConcreteTiles so it's not obstructed by a fence
				this.SubType = 0
				Set("TimeWarp",myTimeWarpFactor)
				local teamAtaken = false
				local teamBtaken = false
				local teamCtaken = false
				local teamDtaken = false
				otherWaterTanks = Find("WaterTank",10000)
				if next(otherWaterTanks) then
					for thatTank, dist in pairs(otherWaterTanks) do
						if thatTank.Id.i ~= this.Id.i and thatTank.TankNr ~= nil then
							if thatTank.TankNr == 0 then teamAtaken = true
							elseif thatTank.TankNr == 1 then teamBtaken = true
							elseif thatTank.TankNr == 2 then teamCtaken = true
							elseif thatTank.TankNr == 3 then teamDtaken = true
							end
						end
					end
				end
				if teamAtaken == false then
					Set("Team","A")
					Set("TankNr",0)
				elseif teamBtaken == false then
					Set("Team","B")
					Set("TankNr",1)
				elseif teamCtaken == false then
					Set("Team","C")
					Set("TankNr",2)
				elseif teamDtaken == false then
					Set("Team","D")
					Set("TankNr",3)
				else
					this.Delete()
					return
				end	-- max 4 tanks allowed
				
				local x = math.floor(this.Pos.x);	local y = math.floor(this.Pos.y)
				local Xmax = 0; local Xmin = 0
				local Ymax = 0; local Ymin = 0
				for i=Ymin-1,Ymax+1 do	for j=Xmin-1,Xmax+1 do	local cell = World.GetCell(x+j,y+i);	cell.Mat = "ConcreteTiles"	end	end
				
				waterWave = Object.Spawn("Sprinkler",this.Pos.x,this.Pos.y)
				waterWave.Hidden = true
				Set("SprinklerSpawned",true)
				timePerUpdate = nil		-- reset to nil so function Update()can proceed normally
			end
		end
	else
		timeInit = timeInit+timePassed
		Now = math.floor(math.mod(World.TimeIndex,60))
		if Now > 50 then
			timeInit = 0
			this.Tooltip = "tooltip_Init_TimeWarpA"
		else
			StartingMinute = Now
		end
	end
end

function FindDistance(x, y, x2, y2)
  local dx, dy = x2 - x, y2 - y
  return math.sqrt(dx*dx + dy*dy)
end

function Find(theObject,theRange) -- returns target objects in a square around the object
	local Xmin=math.ceil(this.Pos.x-theRange/2)
	local Xmax=math.ceil(this.Pos.x+theRange/2)
	local Ymin=math.ceil(this.Pos.y-theRange/2)
	local Ymax=math.ceil(this.Pos.y+theRange/2)
	local ListOfObjects = this.GetNearbyObjects(theObject,theRange*1.2)
	for thatObject, distance in pairs(ListOfObjects) do
		if (thatObject.Pos.x>=Xmin and thatObject.Pos.x<=Xmax) and (thatObject.Pos.y>=Ymin and thatObject.Pos.y<=Ymax) then
		-- it's ok, put other stuff here if you need
		else
			ListOfObjects[thatObject]=nil -- remove the out of bounds object from the list
		end
	end
	return ListOfObjects
end	

function FindFrom(theSource,theObject,theRange)		 -- returns target objects in a square around the object
	local Xmin=math.ceil(theSource.Pos.x-theRange/2)
	local Xmax=math.ceil(theSource.Pos.x+theRange/2)
	local Ymin=math.ceil(theSource.Pos.y-theRange/2)
	local Ymax=math.ceil(theSource.Pos.y+theRange/2)
	local ListOfObjects = Object.GetNearbyObjects(theSource,theObject,theRange*1.2)
	for thatObject, distance in pairs(ListOfObjects) do
		if (thatObject.Pos.x>=Xmin and thatObject.Pos.x<=Xmax) and (thatObject.Pos.y>=Ymin and thatObject.Pos.y<=Ymax) then
		-- it's ok, put other stuff here if you need
		else
			ListOfObjects[thatObject]=nil -- remove the out of bounds object from the list
		end
	end
	return ListOfObjects
end	

function toggleShowCoveredFireAreaClicked()
--	if Covered==true then
--		HideCoveredArea("Fireman")
--		Covered=false
--	else
		ShowCoveredArea(this,FireScanRange,"Fireman")
--		Covered=true
--	end
end

--function HideCoveredArea(theCoverType)
--	for n,v in pairs(CoveredArea[theCoverType]) do
--		CoveredArea[theCoverType][n].Delete()
--	end
--	CoveredArea[theCoverType] = nil
--end

function ShowCoveredArea(theObject,theRange,theCoverType)
	local Xmin=math.ceil(theObject.Pos.x-theRange/2)
	local Xmax=math.ceil(theObject.Pos.x+theRange/2)
	local Ymin=math.ceil(theObject.Pos.y-theRange/2)
	local Ymax=math.ceil(theObject.Pos.y+theRange/2)
	local n=0
	local counter=0
	CoveredArea[theCoverType] = {}
	for i=Ymin,Ymax do
		counter = counter+1
		if counter == 9 then
			counter = 0
			CoveredArea[theCoverType][n] = Object.Spawn(theCoverType.."AreaCovered",Xmin,i)
			CoveredArea[theCoverType][n].Tooltip={"tooltip_CoveredFireArea"}
		end
		n=n+1
	end
	counter = 0
	for i=Xmin,Xmax do
		counter = counter+1
		if counter == 9 then
			counter = 0
			CoveredArea[theCoverType][n] = Object.Spawn(theCoverType.."AreaCovered",i,Ymin)
			CoveredArea[theCoverType][n].Tooltip={"tooltip_CoveredFireArea"}
		end
		n=n+1
	end
	counter = 0
	for i=Ymin,Ymax do
		counter = counter+1
		if counter == 9 then
			counter = 0
			CoveredArea[theCoverType][n] = Object.Spawn(theCoverType.."AreaCovered",Xmax,i)
			CoveredArea[theCoverType][n].Tooltip={"tooltip_CoveredFireArea"}
		end
		n=n+1
	end
	counter = 0
	for i=Xmin,Xmax do
		counter = counter+1
		if counter == 9 then
			counter = 0
			CoveredArea[theCoverType][n] = Object.Spawn(theCoverType.."AreaCovered",i,Ymax)
			CoveredArea[theCoverType][n].Tooltip={"tooltip_CoveredFireArea"}
		end
		n=n+1
	end
end

--			AUTO, MANUAL = by user desired
--			AUTO, -MANUAL- = set by firemanlocker/prisonfireman.lua when team has or hasn't got a crew manager
-- 			when in -MANUAL- mode, user cannot switch back to AUTO: only when a new fireman is hired it will change back to AUTO, unless the tank was set to run in MANUAL mode by the user.
function toggleAutoManualClicked()
	if this.AutoManual == "AUTO" then
		Set("AutoManual","MANUAL")
	elseif this.AutoManual == "MANUAL" then
		Set("AutoManual","AUTO")
	end
	if this.WaterTankBusy == true and this.AutoManual == "AUTO" then
		timeFireCheck = timePerFireCheck
	end
	this.SetInterfaceCaption("toggleAutoManual", "tooltip_button_ToggleAutoManual","tooltip_button_"..this.AutoManual,"X")
	this.Tooltip = { "tooltip_WaterTank",this.HomeUID,"A",this.AutoManual,"B",this.Team,"C",this.myTeam,"X" }
	if not this.FiremanBack and this.CheckForReturningFiremen == true then
		if this.AutoManual == "AUTO" then 
			this.Tooltip = { "tooltip_Watertank_FiremenAutoWaitForReturn",this.HomeUID,"A",this.AutoManual,"B",this.Team,"C",fireNumber,"F",this.myTeam,"X",this.ReturningFiremanNr,"Y",this.DeadFiremanNr,"Z" }
		else
			this.Tooltip = { "tooltip_Watertank_FiremenManualWaitForReturn",this.HomeUID,"A",this.AutoManual,"B",this.Team,"C",this.myTeam,"X",this.ReturningFiremanNr,"Y",this.DeadFiremanNr,"Z" }
		end
	end
end
		




function Set(name, value)
    Object.SetProperty(name, value);
end
function Get(name)
    return Object.GetProperty(name);
end
function GetN(name)
    return tonumber(Object.GetProperty(name));
end
function GetFrom(ident, name)
    return Object.GetProperty(ident, name);
end
function SetOn(ident, name, value)
    return Object.SetProperty(ident, name, value);
end
function Print(text)
    Game.DebugOut("Cat", text);
end
function PrintProperty(name)
    local property = Get(name);
    if property == nil then
        property = "nil";
    end    
    
    Print(name .. ": " .. tostring(property));
end
function PropStr(prop)
    return " " .. prop .. ": " .. tostring(Get(prop));
end--]]


-- get the length of a table
function len(tab)
	local count = 0
	for _ in pairs(tab) do
		count = count + 1
	end
	return count
end
--Return Object if in range.
function GetObject(type,id,dist)
	objs = Object.GetNearbyObjects(type,dist or 1)
	for o,d in pairs(objs) do
		 if o.Id.i == id then
		 	return o
		 end
	end
end
--Find Object after Load.
function Load(Object, Type, ID, dist)
    if Object == "" then
        Print(tostring("Trying to load "..Type.." with ID: "..ID));
        TempID = Get(tostring(ID));
        Object = GetObject(Type,TempID,dist);
        Print("Found: "..Type.." Table: "..tostring(Object).." ID: "..TempID);
    end
	if Object == nil then Set(ID,"None") Object = "" end
    return Object
end
