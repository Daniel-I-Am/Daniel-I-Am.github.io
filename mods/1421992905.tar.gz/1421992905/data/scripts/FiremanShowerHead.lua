
function Create()
	waterWave = Object.Spawn("Sprinkler",this.Pos.x,this.Pos.y)
	this.Slot0.i = waterWave.Id.i
	this.Slot0.u = waterWave.Id.u
	waterWave.CarrierId.i = this.Id.i
	waterWave.CarrierId.u = this.Id.u
	waterWave.Loaded = true
	waterWave.Hidden = true
end

function JobComplete_FiremanTurnOnShowerA0()
end

function JobComplete_FiremanTurnOnShowerA1()
end

function JobComplete_FiremanTurnOnShowerA2()
end

function JobComplete_FiremanTurnOnShowerA3()
end

function JobComplete_FiremanTurnOnShowerB0()
end

function JobComplete_FiremanTurnOnShowerB1()
end

function JobComplete_FiremanTurnOnShowerB2()
end

function JobComplete_FiremanTurnOnShowerB3()
end

function JobComplete_FiremanTurnOnShowerC0()
end

function JobComplete_FiremanTurnOnShowerC1()
end

function JobComplete_FiremanTurnOnShowerC2()
end

function JobComplete_FiremanTurnOnShowerC3()
end

function JobComplete_FiremanTurnOnShowerD0()
end

function JobComplete_FiremanTurnOnShowerD1()
end

function JobComplete_FiremanTurnOnShowerD2()
end

function JobComplete_FiremanTurnOnShowerD3()
end

function JobComplete_FiremanShowerA0()
	Change("A0")
end

function JobComplete_FiremanShowerA1()
	Change("A1")
end

function JobComplete_FiremanShowerA2()
	Change("A2")
end

function JobComplete_FiremanShowerA3()
	Change("A3")
end

function JobComplete_FiremanShowerB0()
	Change("B0")
end

function JobComplete_FiremanShowerB1()
	Change("B1")
end

function JobComplete_FiremanShowerB2()
	Change("B2")
end

function JobComplete_FiremanShowerB3()
	Change("B3")
end

function JobComplete_FiremanShowerC0()
	Change("C0")
end

function JobComplete_FiremanShowerC1()
	Change("C1")
end

function JobComplete_FiremanShowerC2()
	Change("C2")
end

function JobComplete_FiremanShowerC3()
	Change("C3")
end

function JobComplete_FiremanShowerD0()
	Change("D0")
end

function JobComplete_FiremanShowerD1()
	Change("D1")
end

function JobComplete_FiremanShowerD2()
	Change("D2")
end

function JobComplete_FiremanShowerD3()
	Change("D3")
end

function Change(theNr)
	print("finding fireman"..theNr)
	nearbyFireman = this.GetNearbyObjects("PrisonFireman"..theNr,5)
	if next(nearbyFireman) then
		for thatFireman, dist in pairs(nearbyFireman) do
			print("found fireman")
			SetOn(thatFireman,"SubType",3)	-- naked and fresh
			SetOn(thatFireman,"ShowerDone",true)
			SetOn(thatFireman,"Energy",100)
			SetOn(thatFireman,"Damage",0)
			thatFireman.NavigateTo(thatFireman.FiremanLockerX,thatFireman.FiremanLockerY)
			nearbyFireman = nil
			break
		end
	end
	nearbyFireman = nil
	waterWave = this.GetNearbyObjects("Sprinkler",1)
	if next(waterWave) then
		for thatWave, dist in pairs(waterWave) do
			if this.Slot0.i ~= thatWave.Id.i then thatWave.Delete() end
		end
	end
	waterWave = nil
end



-------------------------------------------------------------------------------------------
-- Helper Functions
------------------------------------------------------------------------------------------- 
function Set(name, value)
    Object.SetProperty(name, value);
end
function Get(name)
    return Object.GetProperty(name);
end
function GetN(name)
    return tonumber(Object.GetProperty(name));
end
function GetFrom(ident, name)
    return Object.GetProperty(ident, name);
end
function SetOn(ident, name, value)
    return Object.SetProperty(ident, name, value);
end
function Print(text)
    Game.DebugOut("Cat", text);
end
function PrintProperty(name)
    local property = Get(name);
    if property == nil then
        property = "nil";
    end    
    
    Print(name .. ": " .. tostring(property));
end
function PropStr(prop)
    return " " .. prop .. ": " .. tostring(Get(prop));
end--]]


-- get the length of a table
function len(tab)
	local count = 0
	for _ in pairs(tab) do
		count = count + 1
	end
	return count
end
--Return Object if in range.
function GetObject(type,id,dist)
	objs = Object.GetNearbyObjects(type,dist or 1)
	for o,d in pairs(objs) do
		 if o.Id.i == id then
		 	return o
		 end
	end
end
--Find Object after Load.
function Load(Object, Type, ID, dist)
    if Object == "" then
        Print(tostring("Trying to load "..Type.." with ID: "..ID));
        TempID = Get(tostring(ID));
        Object = GetObject(Type,TempID,dist);
        Print("Found: "..Type.." Table: "..tostring(Object).." ID: "..TempID);
    end
	if Object == nil then Set(ID,"None") Object = "" end
    return Object
end