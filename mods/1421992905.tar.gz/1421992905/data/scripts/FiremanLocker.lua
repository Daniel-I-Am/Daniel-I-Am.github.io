
local timeTot = 0
Fireman = ""
WaterTank = ""

function Create()
	Set("HomeUID","None")
	Set("WaterTankID","None")
	Set("Team","None")
	Set("Member",99)
	Set("CheckForNewMembers",false)
	this.Tooltip = "tooltip_LockerNotInUse"
end

function Update(timePassed)
	if timePerUpdate == nil then
		WaterTank = Load(WaterTank,"WaterTank","WaterTankID",10000)
		if this.HomeUID == "None" then
			this.Tooltip = "tooltip_LockerNotInUse"
		else
			this.Tooltip = { "tooltip_LockerInUse",this.HomeUID,"A",this.Team,"B",(this.Member)+1,"C" }
		end
		timePerUpdate = 5
	end
	
	timeTot = timeTot + timePassed
	if timeTot >= timePerUpdate then
		timeTot = 0
		
		if this.HomeUID ~= "None" then
			if not Get("WaterTankFound") then
				print("Find tank with id")
				print(this.WaterTankID)
				WaterTank = ""
				WaterTank = Load(WaterTank,"WaterTank","WaterTankID",10000)
				if this.WaterTankID ~= "None" then
					this.Tooltip = { "tooltip_LockerInUse",this.HomeUID,"A",this.Team,"B",(this.Member)+1,"C" }
					Set("WaterTankFound",true)
					Set("WaterTankReset",nil)
				end
			elseif Get("WaterTankID") ~= "None" and WaterTank.SubType == nil then
				print("watertankId or subtype error")
				print(WaterTank.SubType)
				Set("HomeUID","None")
				Set("WaterTankID","None")
				Set("Team","None")
				Set("Member",99)
				Set("FiremanFound",nil)
				Set("WaterTankFound",nil)
				Set("WaterTankReset",nil)
				this.Tooltip = "tooltip_LockerNotInUse"
			elseif Get("WaterTankID") ~= "None" and WaterTank.SubType ~= nil and GetFrom(WaterTank,"Member"..this.Member.."ID") == "None" and GetFrom(WaterTank,"Fireman"..this.Member.."ID") == "None" then
				print("fireman was sacked or died in fire")
				if this.Member == 3 and GetFrom(WaterTank,"AutoManual") == "AUTO" then
					SetOn(WaterTank,"AutoManual","-MANUAL-")
					WaterTank.SetInterfaceCaption("toggleAutoManual", "tooltip_button_ToggleAutoManual","tooltip_button_"..WaterTank.AutoManual,"X")
					WaterTank.Tooltip = { "tooltip_WaterTank",WaterTank.HomeUID,"A",WaterTank.AutoManual,"B",WaterTank.Team,"C",WaterTank.myTeam,"X" }
				end
				Set("HomeUID","None")
				Set("WaterTankID","None")
				Set("Team","None")
				Set("Member",99)
				Set("FiremanFound",nil)
				Set("WaterTankFound",nil)
				Set("WaterTankReset",nil)
				this.Tooltip = "tooltip_LockerNotInUse"
			elseif Get("WaterTankID") ~= "None" and WaterTank.SubType ~= nil and GetFrom(WaterTank,"Member"..this.Member.."ID") ~= "None" or GetFrom(WaterTank,"Fireman"..this.Member.."ID") ~= "None" then
				print("tank ok")
				if this.Member == 3 and GetFrom(WaterTank,"AutoManual") == "-MANUAL-" then
					SetOn(WaterTank,"AutoManual","AUTO")
					WaterTank.SetInterfaceCaption("toggleAutoManual", "tooltip_button_ToggleAutoManual","tooltip_button_"..WaterTank.AutoManual,"X")
					WaterTank.Tooltip = { "tooltip_WaterTank",WaterTank.HomeUID,"A",WaterTank.AutoManual,"B",WaterTank.Team,"C",WaterTank.myTeam,"X" }
				end
				this.Tooltip = { "tooltip_LockerInUse",this.HomeUID,"A",this.Team,"B",(this.Member)+1,"C" }
			end
		elseif not Get("WaterTankReset") then
			print("tank reset")
			Set("HomeUID","None")
			Set("WaterTankID","None")
			Set("Team","None")
			Set("Member",99)
			Set("FiremanFound",nil)
			Set("WaterTankFound",nil)
			this.Tooltip = "tooltip_LockerNotInUse"
			Set("WaterTankReset",true)
		end
	end
end


function JobComplete_ChangeFiremanClothesA0()
	Change("A0")
end

function JobComplete_ChangeFiremanClothesA1()
	Change("A1")
end

function JobComplete_ChangeFiremanClothesA2()
	Change("A2")
end

function JobComplete_ChangeFiremanClothesA3()
	Change("A3")
end

function JobComplete_ChangeFiremanClothesB0()
	Change("B0")
end

function JobComplete_ChangeFiremanClothesB1()
	Change("B1")
end

function JobComplete_ChangeFiremanClothesB2()
	Change("B2")
end

function JobComplete_ChangeFiremanClothesB3()
	Change("B3")
end

function JobComplete_ChangeFiremanClothesC0()
	Change("C0")
end

function JobComplete_ChangeFiremanClothesC1()
	Change("C1")
end

function JobComplete_ChangeFiremanClothesC2()
	Change("C2")
end

function JobComplete_ChangeFiremanClothesC3()
	Change("C3")
end

function JobComplete_ChangeFiremanClothesD0()
	Change("D0")
end

function JobComplete_ChangeFiremanClothesD1()
	Change("D1")
end

function JobComplete_ChangeFiremanClothesD2()
	Change("D2")
end

function JobComplete_ChangeFiremanClothesD3()
	Change("D3")
end

function Change(theNr)
	print("finding fireman"..theNr)
	nearbyFireman = this.GetNearbyObjects("PrisonFireman"..theNr,5)
	if next(nearbyFireman) then
		for thatFireman, dist in pairs(nearbyFireman) do
			print("found fireman")
			Fireman = thatFireman
		end
	end
	if Fireman.SubType == 1 then		-- has dirty clothes
		print("found my dirty fireman"..theNr.." with id "..Fireman.Id.i..", making naked")
		SetOn(Fireman,"SubType",2)	-- make him naked, type 2 triggers him to go to shower
		nearbyFireman = nil
	elseif Fireman.SubType == 3 then		-- naked, type 3 triggered him to come back here
		print("found my naked fireman"..theNr.." with id "..Fireman.Id.i..", putting clothes on")
		SetOn(Fireman,"SubType",0)
		SetOn(Fireman,"ClothesOn",nil)
		SetOn(Fireman,"ShowerSequenceStarted",false)
		if theNr == "A0" or theNr == "B0" or theNr == "C0" or theNr == "D0" then
			X = GetFrom(Fireman,"WaterTankX")-1.15
			Y = GetFrom(Fireman,"WaterTankY")-1.15
		elseif theNr == "A1" or theNr == "B1" or theNr == "C1" or theNr == "D1" then
			X = GetFrom(Fireman,"WaterTankX")+1.15
			Y = GetFrom(Fireman,"WaterTankY")-1.15
		elseif theNr == "A2" or theNr == "B2" or theNr == "C2" or theNr == "D2" then
			X = GetFrom(Fireman,"WaterTankX")-1.15
			Y = GetFrom(Fireman,"WaterTankY")+1.15
		elseif theNr == "A3" or theNr == "B3" or theNr == "C3" or theNr == "D3" then
			X = GetFrom(Fireman,"WaterTankX")+1.15
			Y = GetFrom(Fireman,"WaterTankY")+1.15
		end
	--	Fireman.NavigateTo(X,Y)
		if theNr == "A3" or theNr == "B3" or theNr == "C3" or theNr == "D3" then
			if GetFrom(WaterTank,"WaterTankBusy") == false then
				Object.CreateJob(WaterTank,"InspectWaterTank"..theNr)
			end
		end
	end
end



-------------------------------------------------------------------------------------------
-- Helper Functions
------------------------------------------------------------------------------------------- 
function Set(name, value)
    Object.SetProperty(name, value);
end
function Get(name)
    return Object.GetProperty(name);
end
function GetN(name)
    return tonumber(Object.GetProperty(name));
end
function GetFrom(ident, name)
    return Object.GetProperty(ident, name);
end
function SetOn(ident, name, value)
    return Object.SetProperty(ident, name, value);
end
function Print(text)
    Game.DebugOut("Cat", text);
end
function PrintProperty(name)
    local property = Get(name);
    if property == nil then
        property = "nil";
    end    
    
    Print(name .. ": " .. tostring(property));
end
function PropStr(prop)
    return " " .. prop .. ": " .. tostring(Get(prop));
end--]]


-- get the length of a table
function len(tab)
	local count = 0
	for _ in pairs(tab) do
		count = count + 1
	end
	return count
end
--Return Object if in range.
function GetObject(type,id,dist)
	objs = Object.GetNearbyObjects(type,dist or 1)
	for o,d in pairs(objs) do
		 if o.Id.i == id then
		 	return o
		 end
	end
end
--Find Object after Load.
function Load(Object, Type, ID, dist)
    if Object == "" then
        Print(tostring("Trying to load "..Type.." with ID: "..ID));
        TempID = Get(tostring(ID));
        Object = GetObject(Type,TempID,dist);
        Print("Found: "..Type.." Table: "..tostring(Object).." ID: "..TempID);
    end
	if Object == nil then Set(ID,"None") Object = "" end
    return Object
end