local timeTot = 0

Fireman0 = ""
Fireman1 = ""
Fireman2 = ""
Fireman3 = ""

local fireNumber = 0
local FireScanRange = 75


function Create()
	Set("TotalFound",0)
    Set("Fireman0ID","None")
    Set("Fireman1ID","None")
    Set("Fireman2ID","None")
    Set("Fireman3ID","None")
	Set("WaterTankID","None")
end

function Update(timePassed)
	if timePerUpdate == nil then
	-------------------------------------------------------------------------------------------
	-- Load References
	-------------------------------------------------------------------------------------------
		Fireman0 = Load(Fireman0,"Fireman","Fireman0ID",10000)
		Fireman1 = Load(Fireman1,"Fireman","Fireman1ID",10000)
		Fireman2 = Load(Fireman2,"Fireman","Fireman2ID",10000)
		Fireman3 = Load(Fireman3,"Fireman","Fireman3ID",10000)

		timePerUpdate = 0.5
	end
	-------------------------------------------------------------------------------------------
	
	timeTot = timeTot + timePassed
	if timeTot >= timePerUpdate then
		timeTot = 0
		
		if not Get("FiremanFound") then		-- first find the callout firemen
			nearbyFireman = this.GetNearbyObjects("Fireman",10000)
			if next(nearbyFireman) then
				for thatFireman , d in pairs(nearbyFireman) do
					for j=0,3 do
						if Get("Slot"..j..".i") == thatFireman.Id.i then
							Set("Fireman"..j.."ID",thatFireman.Id.i)
						end
					end
				end
				Fireman0 = ""
				Fireman1 = ""
				Fireman2 = ""
				Fireman3 = ""
				Fireman0 = Load(Fireman0,"Fireman","Fireman0ID",10000)
				Fireman1 = Load(Fireman1,"Fireman","Fireman1ID",10000)
				Fireman2 = Load(Fireman2,"Fireman","Fireman2ID",10000)
				Fireman3 = Load(Fireman3,"Fireman","Fireman3ID",10000)
				if Get("Fireman0ID") ~= "None" and Get("Fireman1ID") ~= "None" and Get("Fireman2ID") ~= "None" and Get("Fireman3ID") ~= "None" then 
					Set("FiremanFound",true)
				end
			end
		elseif not Get("WaterTankFound") then	-- find Prison firemen and a watertank near fires
			local CurrentDist = 10000
			nearbyTank = this.GetNearbyObjects("WaterTank",10000)
			if next(nearbyTank) then
				for thatTank, d in pairs(nearbyTank) do
					if GetFrom(thatTank,"AutoManual") == "MANUAL" and GetFrom(thatTank,"WaterTankSearcherID") == "None" and GetFrom(thatTank,"myTeam") > 0 then
						myTank = thatTank
					else
						fireNumber = 0
						if GetFrom(thatTank,"WaterTankSearcherID") == "None" and GetFrom(thatTank,"myTeam") > 0 then
							local nearbyFires = FindFrom(thatTank,"Fire",FireScanRange)
							for thatFire, dist in pairs(nearbyFires) do
								fireNumber = fireNumber+1
								if dist <= CurrentDist then
									CurrentDist = dist
									myTank = thatTank
								end
							end
						end
					end
				end
				if myTank == nil then		-- no unused WaterTanks found within range of any fire, so get rid of the callout
					Fireman0.Delete()
					Fireman1.Delete()
					Fireman2.Delete()
					Fireman3.Delete()
					this.Delete()
					return
				else
					Set("WaterTankID",myTank.Id.i)
				end
				if myTank.myTeam == 0 then		-- no Prison Firemen found, so get rid of the callout
					Fireman0.Delete()
					Fireman1.Delete()
					Fireman2.Delete()
					Fireman3.Delete()
					this.Delete()
					return
				end
				
				SetOn(myTank,"WaterTankSearcherID",this.Id.i)
				myTank.SubType = 1
				this.Pos.x = myTank.Pos.x+1.75		-- teleport to a spot where the hose will be behind the WaterTank
				this.Pos.y = myTank.Pos.y+2.5		-- hose appears at some hard coded spot on firetruck (left side, back end of truck)? so this is to compensate for that location

				if myTank.Member0ID == "None" then SetOn(myTank,"Fireman0Available",false); Fireman0.Delete() else SetOn(myTank,"Fireman0Available",true); Fireman0.Damage = 0; Swap(Fireman0,0,this.Slot0,myTank.Slot4); newHose0 = Object.Spawn("HoseIcon",myTank.Pos.x+0.05,myTank.Pos.y+0.25);	SetOn(newHose0,"HoseNr",0) end
				if myTank.Member1ID == "None" then SetOn(myTank,"Fireman1Available",false); Fireman1.Delete() else SetOn(myTank,"Fireman1Available",true); Fireman1.Damage = 0; Swap(Fireman1,1,this.Slot1,myTank.Slot5); newHose1 = Object.Spawn("HoseIcon",myTank.Pos.x+0.15,myTank.Pos.y+0.25);	SetOn(newHose1,"HoseNr",1) end
				if myTank.Member2ID == "None" then SetOn(myTank,"Fireman2Available",false); Fireman2.Delete() else SetOn(myTank,"Fireman2Available",true); Fireman2.Damage = 0; Swap(Fireman2,2,this.Slot2,myTank.Slot6); newHose2 = Object.Spawn("HoseIcon",myTank.Pos.x+0.25,myTank.Pos.y+0.25);	SetOn(newHose2,"HoseNr",2) end
				if myTank.Member3ID == "None" then SetOn(myTank,"Fireman3Available",false); Fireman3.Delete() else SetOn(myTank,"Fireman3Available",true); Fireman3.Damage = 0; Swap(Fireman3,3,this.Slot3,myTank.Slot7); newHose3 = Object.Spawn("HoseIcon",myTank.Pos.x+0.35,myTank.Pos.y+0.25);	SetOn(newHose3,"HoseNr",3) end

				SetOn(myTank,"WaterTankBusy",true)		-- ready to be processed by the WaterTank
				if GetFrom(myTank,"AutoManual") == "AUTO" then
					myTank.Tooltip = {"tooltip_Watertank_FiremenAvailableAuto",myTank.HomeUID,"A",myTank.AutoManual,"B",myTank.Team,"C",fireNumber,"F",myTank.myTeam,"X"}
				else
					myTank.Tooltip = {"tooltip_Watertank_FiremenAvailableManual",myTank.HomeUID,"A",myTank.AutoManual,"B",myTank.Team,"C",myTank.myTeam,"X"}
				end
				Set("WaterTankFound",true)
				timePerUpdate = 60 / 0.75
			else										-- no WaterTank nor fires found, so get rid of the callout
				Fireman0.Delete()
				Fireman1.Delete()
				Fireman2.Delete()
				Fireman3.Delete()
				this.Delete()
			end
		end
	end
end


function Swap(theFireman,theID,fromSlot,toSlot)
	SetOn(myTank,"Fireman"..theID.."ID",theFireman.Id.i)
	fromSlot.i = -1
	fromSlot.u = -1
	toSlot.i = theFireman.Id.i		-- load them onto Slot 4-7 at the WaterTank: when they return they want to get in Slot0-3
	toSlot.u = theFireman.Id.u		-- so this way fresh firemen should never collide with returning firemen in case that gets implemented
	theFireman.CarrierId.i = myTank.Id.i
	theFireman.CarrierId.u = myTank.Id.u
	theFireman.Loaded = true
	theFireman.Tooltip = "tooltip_QueuedFireman"
	SetOn(theFireman,"IsPrisonFireman",true)
	SetOn(theFireman,"KilledInAction",false)
	theFireman.SubType = 4			-- subtype 4 is an empty sprite, so the guy is hidden for now
	theFireman.Equipment = 0		-- hide his hose as well, otherwise we see two hands holding a hose and no fireman
	theFireman.FireEngine.i = this.Id.i		-- set the FireEngine to me for the moment, it will swap after grab hose jobs
	theFireman.FireEngine.u = this.Id.u
end




function FindFrom(theSource,theObject,theRange)		 -- returns target objects in a square around the object
	local Xmin=math.ceil(theSource.Pos.x-theRange/2)
	local Xmax=math.ceil(theSource.Pos.x+theRange/2)
	local Ymin=math.ceil(theSource.Pos.y-theRange/2)
	local Ymax=math.ceil(theSource.Pos.y+theRange/2)
	local ListOfObjects = Object.GetNearbyObjects(theSource,theObject,theRange*1.2)
	for thatObject, distance in pairs(ListOfObjects) do
		if (thatObject.Pos.x>=Xmin and thatObject.Pos.x<=Xmax) and (thatObject.Pos.y>=Ymin and thatObject.Pos.y<=Ymax) then
		-- it's ok, put other stuff here if you need
		else
			ListOfObjects[thatObject]=nil -- remove the out of bounds object from the list
		end
	end
	return ListOfObjects
end	











-------------------------------------------------------------------------------------------
-- Helper Functions
------------------------------------------------------------------------------------------- 
function Set(name, value)
    Object.SetProperty(name, value);
end
function Get(name)
    return Object.GetProperty(name);
end
function GetN(name)
    return tonumber(Object.GetProperty(name));
end
function GetFrom(ident, name)
    return Object.GetProperty(ident, name);
end
function SetOn(ident, name, value)
    return Object.SetProperty(ident, name, value);
end
function Print(text)
    Game.DebugOut("Cat", text);
end
function PrintProperty(name)
    local property = Get(name);
    if property == nil then
        property = "nil";
    end    
    
    Print(name .. ": " .. tostring(property));
end
function PropStr(prop)
    return " " .. prop .. ": " .. tostring(Get(prop));
end--]]


-- get the length of a table
function len(tab)
	local count = 0
	for _ in pairs(tab) do
		count = count + 1
	end
	return count
end
--Return Object if in range.
function GetObject(type,id,dist)
	objs = Object.GetNearbyObjects(type,dist or 1)
	for o,d in pairs(objs) do
		 if o.Id.i == id then
		 	return o
		 end
	end
end
--Find Object after Load.
function Load(Object, Type, ID, dist)
    if Object == "" then
        Print(tostring("Trying to load "..Type.." with ID: "..ID));
        TempID = Get(tostring(ID));
        Object = GetObject(Type,TempID,dist);
        Print("Found: "..Type.." Table: "..tostring(Object).." ID: "..TempID);
    end
	if Object == nil then Set(ID,"None") Object = "" end
    return Object
end