
function CreateGrants()
	CreateFireBrigade()
end

function CreateFireBrigade()
	Objective.CreateGrant			( "Grant_FireBrigade", 1500, 2500 )

	Objective.CreateGrant			( "Grant_FireBrigade_WaterTankNumber", 0, 0 )
	Objective.SetParent				( "Grant_FireBrigade" )
	Objective.RequireObjects		( "WaterTank", 1 )
	
	Objective.CreateGrant			( "Grant_FireBrigade_FireBrigadeRoom", 0, 0 )
	Objective.SetParent				( "Grant_FireBrigade" )
	Objective.RequireRoom			( "PrisonFireBrigade", true )
	
	Objective.CreateGrant			( "Grant_FireBrigade_LockerNumber", 0, 0 )
	Objective.SetParent				( "Grant_FireBrigade" )
	Objective.RequireObjects		( "FiremanLocker", 4 )
	
	Objective.CreateGrant			( "Grant_FireBrigade_ShowerNumber", 0, 0 )
	Objective.SetParent				( "Grant_FireBrigade" )
	Objective.RequireObjects		( "FiremanShowerHead", 4 )
	
	Objective.CreateGrant			( "Grant_FireBrigade_FiremenNumber", 0, 0 )
	Objective.SetParent				( "Grant_FireBrigade" )
	Objective.RequireObjects		( "PrisonFiremanA0", 1 )
	Objective.RequireObjects		( "PrisonFiremanA1", 1 )
	Objective.RequireObjects		( "PrisonFiremanA2", 1 )
	Objective.RequireObjects		( "PrisonFiremanA3", 1 )
	
	Objective.CreateGrant			( "Grant_FireBrigade_FireStarter", 0, 0 )
	Objective.SetParent				( "Grant_FireBrigade" )
	Objective.RequireObjects		( "Fire", 20 )
	
end
