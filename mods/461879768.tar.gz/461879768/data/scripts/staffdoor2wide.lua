local pt  = false
local function OpenDebugScreen()
    if not pt then
        pt = true
        print()
    end
end

-- CONFIG HERE
local DoorWidth     = 2         -- width of door
local DoorOpenSpeed = 0.7       -- speed of door opening
local IsRemote      = false     -- not implemented yet
local ReqiresKey    = false     -- not implemented yet
local CanOpenEntity = {         --
    -- Staff
    Workman             = true,
    Guard               = true,
    ArmedGuard          = true,
    DogHandler          = true,
    Dog                 = true,
    Doctor              = true,
    Cook                = true,
    Janitor             = true,
    Gardener            = true,
    -- Special Staff (Bureaucracy)
    Warden              = true,
    Chief               = true,
    Foreman             = true,
    Psychologist        = true,
    Accountant          = true,
    Lawyer              = true,
    -- Emergency
    Soldier             = true,
    RiotGuard           = true,
    Fireman             = true,
    Paramedic           = true,
    -- Partially Staff
    ExecutionWitness    = false,
    Actor               = false,
    Teacher             = false,
    SpiritualLeader     = false,
    ParoleOfficer       = false,
    ParoleLawyer        = false,
    AppealsLawyer       = false,
    AppealsMagistrate   = false,
    
    -- Not Staff
    TruckDriver         = false,
    Visitor             = false,
    Prisoner            = false,
}


-- CONFIG END


-- Do not change Anything here
-- Runtime Variables Start
local DoorCloseMax   = 0.00001
local UpdateTime     = -2 -- Start negative, so the Workman can "escape"
local DoorOpening    = false
local DoorOpenStat   = tonumber(this.Open) or DoorCloseMax
local JobCreated     = 0
-- Runtime Variables END

function UpdateTooltip()
    if not TooltipIsSet then
        TooltipIsSet = true
        
        local s,s2 = "",""
        for a, b in pairs(CanOpenEntity) do
            if b then
                s = s..a..', '
            else
                s2 = s2..a..', '
            end
        end
        s = string.sub(s,0,string.len(s)-2)
        s2 = string.sub(s2,0,string.len(s2)-2)
        
        local out = ""
        if s ~= "" then
            out = "Open for: "..s.."\n"
        end
        if s2 ~= "" then
            out = out.."Closed for: "..s2
        end
        
        Object.SetProperty("Tooltip",out);
    end
end

function Create()
    this.Open = 1 -- start open
    DoorOpenStat = this.Open
    UpdateTooltip()
end



function Update(timePassed)
    -- OpenDebugScreen()
    
    UpdateTime = UpdateTime + tonumber(timePassed)
    if UpdateTime >= 1 then 
        UpdateTime = 0
        PerformTickUpdate()
        -- return 
    end

    PerformTickMove(timePassed)

end

function PerformTickUpdate()
    if this.Mode == "LockedOpen" then
        SetOpen()
    elseif this.Mode == "LockedShut" then
        SetClose()
    else
        -- Check for Open.. or Close lol
        CheckForPerson()
    end
end

function PerformTickMove(timePassed)
    if DoorOpening then
        DoorOpenStat = DoorOpenStat + (timePassed * DoorOpenSpeed)
    else
        DoorOpenStat = DoorOpenStat - (timePassed * DoorOpenSpeed)
    end
    
    SetDoorOpenPos(DoorOpenStat)
end

function SetOpen() -- Open the Door
    DoorOpening    = true
    JobCreated     = 0
end

function SetClose() -- Close the Door
    DoorOpening = false
end

function SetDoorOpenPos(val)
    DoorOpenStat = math.max(DoorCloseMax,math.min(1,val))
    this.Open = DoorOpenStat
end

-- Search for Persons to get in
function CheckForPerson()
    local rot = getOrientation()
    local x, y   = math.floor(this.Pos.x), math.floor(this.Pos.y)
    local function CheckPos(ptab) 
        local function CheckInRange(myPos, newPos) 
            Game.DebugOut(newPos.." - "..myPos)
            return newPos >= myPos+1-DoorWidth-0.3 and newPos <= myPos+1+0.3
        end
        if ptab.Pos.x == this.Pos.x and ptab.Pos.y == this.Pos.y then
            -- Fix for Stuck people
            return true
        end
        -- Check for Position
        local fX,fY = math.floor(ptab.Pos.x),math.floor(ptab.Pos.y)
        local nX,nY = math.abs(ptab.Pos.x - x), math.abs(ptab.Pos.y -y)
        local max = 0.5
        if rot == 0 or rot == 2 then
            return CheckInRange(x,fX) and not (nY-1 > 0.3)
        elseif rot == 1 or rot == 3 then
            return CheckInRange(y,fY) and not (nX-1 > 0.3)
        end
        
        return true
    end
    local found     = false
    local jobNeeded = true
    for i,canOpenThisDoor in pairs(CanOpenEntity) do
        local founds = Object.GetNearbyObjects(i, DoorWidth);
        for ptab,_ in pairs(founds) do
            if CheckPos(ptab) then
                if canOpenThisDoor then
                    jobNeeded = false
                end
                found = true
            end
        end
    end
    
    -- Yahee, we found someone that wants to get inside!
    if found then
        if jobNeeded then
            -- Find some person that can open this door..
            if (not JobCreated) or (JobCreated + 15 < Game.Time())  then
                SetOpenDoorCommand()
            end
        else
            SetOpen()
        end
    else
        SetClose()
    end
end


-- Can I Open the door? Send some one!!
function SetOpenDoorCommand() 
    local nearestWithJob    = {nil,999}
    local nearestWithoutJob = {nil,999}
    for i,canOpenThisDoor in pairs(CanOpenEntity) do
        if canOpenThisDoor then
            local founds = Object.GetNearbyObjects(i, math.max(nearestWithJob[2],nearestWithoutJob[2]));
            for ptab, distance in pairs(founds) do
                local distance = tonumber(distance) or 0
                if (tonumber(ptab.JobId) or 0) > 0 then                    
                    if nearestWithJob[2] > distance then
                        nearestWithJob = {ptab,distance}
                    end
                else                
                    if nearestWithoutJob[2] > distance then
                        nearestWithoutJob = {ptab,distance}
                    end
                end
            end
        end
    end
    
    local nearest = nearestWithoutJob[1] or nearestWithJob[1]
    if nearest then
        Object.CreateJob("OpenDoor"..nearest.Type)
        JobCreated = Game.Time()
        
    end
    
end

-- current Object Orientation
function  getOrientation() 
 --[[
    Orientation:    Or.x    Or.y
        Down:       0       1
        Left:       -1       0
        Up:         0       -1
        Right:      1       0
    Result:
    0 = down
    1 = left
    2 = up
    3 = right
 --]]
    local function nearNum(inp,num)
        return math.abs(inp-num) < 0.001
    end
    local rx = this.Or.x
    local ry = this.Or.y
    if nearNum(rx,0) and nearNum(ry,1) then
        return 0
    elseif nearNum(rx,-1) and nearNum(ry,0) then
        return 1
    elseif nearNum(rx,0) and nearNum(ry,-1) then
        return 2
    elseif nearNum(rx,1) and nearNum(ry,0) then
        return 3
    else
        return -1
    end
end



-- Job stuff (to open the door)
function resetJob()
    JobCreated = 0
end

function JobComplete_OpenDoorActor() resetJob() end
function JobComplete_OpenDoorWarden() resetJob() end
function JobComplete_OpenDoorForeman() resetJob() end
function JobComplete_OpenDoorSpiritualLeader() resetJob() end
function JobComplete_OpenDoorSoldier() resetJob() end
function JobComplete_OpenDoorAppealsMagistrate() resetJob() end
function JobComplete_OpenDoorAccountant() resetJob() end
function JobComplete_OpenDoorTruckDriver() resetJob() end
function JobComplete_OpenDoorChief() resetJob() end
function JobComplete_OpenDoorPsychologist() resetJob() end
function JobComplete_OpenDoorParoleOfficer() resetJob() end
function JobComplete_OpenDoorExecutionWitness() resetJob() end
function JobComplete_OpenDoorArmedGuard() resetJob() end
function JobComplete_OpenDoorVisitor() resetJob() end
function JobComplete_OpenDoorDog() resetJob() end
function JobComplete_OpenDoorWorkman() resetJob() end
function JobComplete_OpenDoorAppealsLawyer() resetJob() end
function JobComplete_OpenDoorJanitor() resetJob() end
function JobComplete_OpenDoorTeacher() resetJob() end
function JobComplete_OpenDoorDogHandler() resetJob() end
function JobComplete_OpenDoorFireman() resetJob() end
function JobComplete_OpenDoorRiotGuard() resetJob() end
function JobComplete_OpenDoorParamedic() resetJob() end
function JobComplete_OpenDoorPrisoner() resetJob() end
function JobComplete_OpenDoorParoleLawyer() resetJob() end
function JobComplete_OpenDoorCook() resetJob() end
function JobComplete_OpenDoorLawyer() resetJob() end
function JobComplete_OpenDoorDoctor() resetJob() end
function JobComplete_OpenDoorGuard() resetJob() end
function JobComplete_OpenDoorGardener() resetJob() end
